using System;
using System.Collections;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Web;
using System.Web.SessionState;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Web.UI.HtmlControls;

using System.Data.OleDb;


namespace ASPInterOp
{
	/// <summary>
	/// Summary description for ASPInterOpNoCOMTest.
	/// </summary>
	public class ASPInterOpNoCOMTest : System.Web.UI.Page
	{
		private void Page_Load(object sender, System.EventArgs e)
		{
			// Put user code to initialize the page here
			OleDbConnection oConn = null;

			string Connect = @"Provider=vfpoledb.1;Data Source=D:\wwapps\wc3\asp;Exclusive=off";
			string CounterName = "rick";

			string Query = "SELECT name,counter from WebCounters where name='" + CounterName + "'";

			try 
			{
				oConn = new OleDbConnection(Connect);
			}
		    catch(Exception ex) 
			{
				string lcError = ex.Message;
			}

			OleDbCommand oCommand = new OleDbCommand(Query,oConn);

			oConn.Open();
			OleDbDataReader oReader;
			oReader = oCommand.ExecuteReader();

			if (!oReader.Read()) 
			{
				oReader.Close();
				//*** create key
				oCommand =	new OleDbCommand("insert webcounters (name,counter) values (0,'" + CounterName + "')",oConn);
				int lnResult = oCommand.ExecuteNonQuery();
			}
			else 
			{
				int lnValue = oReader.GetInt32(1) + 1;
				oReader.Close();
				string lcSQL = "update webcounters set counter=" + lnValue.ToString() + " where name='" + CounterName + "'";
				oCommand =	new OleDbCommand(lcSQL,oConn);
				int lnResult = oCommand.ExecuteNonQuery();
			}


		}

		#region Web Form Designer generated code
		override protected void OnInit(EventArgs e)
		{
			//
			// CODEGEN: This call is required by the ASP.NET Web Form Designer.
			//
			InitializeComponent();
			base.OnInit(e);
		}
		
		/// <summary>
		/// Required method for Designer support - do not modify
		/// the contents of this method with the code editor.
		/// </summary>
		private void InitializeComponent()
		{    
			this.Load += new System.EventHandler(this.Page_Load);
		}
		#endregion
	}
}
