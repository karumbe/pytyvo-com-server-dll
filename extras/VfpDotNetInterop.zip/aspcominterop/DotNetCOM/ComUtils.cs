using System;
using System.Reflection;

namespace Westwind.Tools
{
	/// <summary>
	/// A set of Reflection functions that simplify accessing
	/// properties and methods dynamically from returned VFP data
	/// </summary>
	public class ComUtils
	{
		
		/// <summary>
		/// Retrieve a dynamic 'non-typelib' property
		/// </summary>
		/// <param name="loObject"></param>
		/// <param name="lcProperty"></param>
		/// <returns></returns>
		public static object GetProperty(object loObject,string lcProperty)
		{
			return loObject.GetType().InvokeMember(lcProperty,BindingFlags.GetProperty,null,loObject,null);
		}

		/// <summary>
		/// Retrieve a dynamic 'non-typelib' field
		/// </summary>
		/// <param name="loObject"></param>
		/// <param name="lcProperty"></param>
		/// <returns></returns>
		public static object GetField(object loObject,string lcProperty)
		{
			return loObject.GetType().InvokeMember(lcProperty,BindingFlags.GetField,null,loObject,null);
		}

		/// <summary>
		/// Returns a property value using a base object and sub members including . syntax.
		/// For example, you can access: this.oCustomer.oData.Company with (this,"oCustomer.oData.Company")
		/// </summary>
		/// <param name="loParent">Parent object to 'start' parsing from.</param>
		/// <param name="lcProperty">The property to retrieve. Example: 'oBus.oData.Company'</param>
		/// <returns></returns>
		public static object GetPropertyEx(object loParent, string lcProperty) 
		{
			Type loType = loParent.GetType();

			int lnAt = lcProperty.IndexOf(".");
			if ( lnAt < 0)
				if (loType.GetMember(lcProperty)[0].MemberType == MemberTypes.Property )
				{
					return  loType.InvokeMember(lcProperty,
						System.Reflection.BindingFlags.GetProperty,
						null,loParent,null);
				}
				else
				{
					return  loType.InvokeMember(lcProperty,
						System.Reflection.BindingFlags.GetField,
						null,loParent,null);
				}

			// *** Walk the . syntax
			string lcMain = lcProperty.Substring(0,lnAt);
			string lcSubs = lcProperty.Substring(lnAt+1);

			object loSub;
			if (loType.GetMember(lcMain)[0].MemberType == MemberTypes.Property )
			{
				loSub = loType.InvokeMember(lcMain,
					System.Reflection.BindingFlags.GetProperty,
					null,loParent,null);
			}
			else
			{
				loSub = loType.InvokeMember(lcMain,
					System.Reflection.BindingFlags.GetField,
					null,loParent,null);
			}

			// *** Recurse until we get the lowest ref
			return GetPropertyEx(loSub,lcSubs);
		}

		public static object SetProperty(object loObject,string lcProperty,params object[] loValue)
		{
			return loObject.GetType().InvokeMember(lcProperty,BindingFlags.SetProperty,null,loObject,loValue);
		}

		public static object SetField(object loObject,string lcProperty,params object[] loValue)
		{
			return loObject.GetType().InvokeMember(lcProperty,BindingFlags.SetField,null,loObject,loValue);
		}

		public static object SetPropertyEx(object loParent, string lcProperty,params object[] loValue) 
		{
			Type loType = loParent.GetType();
			bool llProperty = (loType.GetMember(lcProperty)[0].MemberType == MemberTypes.Property);

			// *** no more .s - we got our final object
			int lnAt = lcProperty.IndexOf(".");
			if ( lnAt < 0) 
			{
				if ( llProperty )
					return  loType.InvokeMember(lcProperty,
						System.Reflection.BindingFlags.SetProperty,
						null,loParent,loValue);
				else
					return  loType.InvokeMember(lcProperty,
						System.Reflection.BindingFlags.SetField,
						null,loParent,loValue);
			}	
				
			// *** Walk the . syntax
			string lcMain = lcProperty.Substring(0,lnAt);
			string lcSubs = lcProperty.Substring(lnAt+1);

			object loSub;
			if (llProperty)
				loSub = loType.InvokeMember(lcMain,
					System.Reflection.BindingFlags.GetProperty,
					null,loParent,null);
			else
				loSub = loType.InvokeMember(lcMain,
					System.Reflection.BindingFlags.GetField,
					null,loParent,null);

			// *** Recurse until we get the lowest ref
			return SetPropertyEx(loSub,lcSubs,loValue);
		}

		/// <summary>
		/// Wrapper method to call a 'dynamic' (non-typelib) method
		/// on a COM object
		/// </summary>
		/// <param name="loParams"></param>
		/// 1st - Method name, 2nd - 1st parameter, 3rd - 2nd parm etc.
		/// <returns></returns>
		public static object CallMethod(object loObject,string lcMethod, params object[] loParams)
		{
			return loObject.GetType().InvokeMember(lcMethod,
				BindingFlags.InvokeMethod,null,loObject,loParams);
		}


	}
}
