using System;
using System.Drawing;
using System.Drawing.Imaging;

using System.Runtime.InteropServices;

namespace DotNetCOM
{
	/// <summary>
	/// Summary description for wwImaging.
	/// </summary>
	/// 
	[ClassInterface(ClassInterfaceType.AutoDual)]
	[ProgId("DotNetCOM.wwImaging")]	
	public class wwImaging
	{

		public string cErrorMsg = "";
		public bool bError = false;

		public wwImaging()
		{
			//
			// TODO: Add constructor logic here
			//
		}		
		public void Dispose()
		{
		}

		/// <summary>
		/// Creates a thumbnail from an existing file. 
		/// Thumbnail is sized to width or height depending on image orientation - 
		/// the larger 'side' of the image is sized, so if the width is longer the thumbnail
		/// is sized to the lnWidth specification, if it's taller then to lnHeight.
		/// </summary>
		/// <param name="lcFilename">Original image file</param>
		/// <param name="lcThumbnailFilename">Output thumbnail file</param>
		/// <param name="lnWidth">Width of the thumbnail</param>
		/// <param name="lnHeight">Height of the thumbnail</param>
		/// <returns></returns>
		public bool CreateThumbnail(string lcFilename, string lcThumbnailFilename,int lnWidth, int lnHeight)
		{
			try 
			{
				Bitmap loBMP = new Bitmap(lcFilename);
				ImageFormat loFormat = loBMP.RawFormat;

				decimal lnRatio;
				int lnNewWidth = 0;
				int lnNewHeight = 0;

				//*** If the image is smaller than a thumbnail just return it
				if (loBMP.Width < lnWidth && loBMP.Height < lnHeight) 
				{
					loBMP.Save(lcThumbnailFilename);
					return true;
				}

				if (loBMP.Width > loBMP.Height)
				{
					lnRatio = (decimal) lnWidth / loBMP.Width;
					lnNewWidth = lnWidth;
					decimal lnTemp = loBMP.Height * lnRatio;
					lnNewHeight = (int)lnTemp;
				}
				else 
				{
					lnRatio = (decimal) lnHeight / loBMP.Height;
					lnNewHeight = lnHeight;
					decimal lnTemp = loBMP.Width * lnRatio;
					lnNewWidth = (int) lnTemp;
				}

				System.Drawing.Image imgOut = loBMP.GetThumbnailImage(lnNewWidth,lnNewHeight,null,IntPtr.Zero);
					
				loBMP.Dispose();
		
				imgOut.Save(lcThumbnailFilename,loFormat);
				imgOut.Dispose();

			}
			catch (Exception ex) 
			{
				this.SetError(ex.Message);
				return false;
			}
			
			return true;
		}

		/// <summary>
		/// Rotates an image file in place.
		/// </summary>
		/// <param name="lcFileName">Filename to rotate.</param>
		/// <param name="lnRotation">1 - 90 degrees, 2 - 180, 3 - 270, 4 - Flip, 5 - Rotate 90 and flip etc.</param>
		/// <returns>True or False</returns>
		public bool RotateImage(string lcFileName, int lnRotation) 
		{
			try 
			{ 
				Bitmap  loImage = new Bitmap(lcFileName);
				
				loImage.RotateFlip((RotateFlipType) lnRotation);

				loImage.Save(lcFileName);
				return true;
			}
			catch(Exception) {;}

			return false;
		}
	    
		public wwImageInfo GetImageInfo(string lcImageFile)
		{
			try 
			{
				Bitmap loBMP = new Bitmap(lcImageFile);
				
				wwImageInfo loInfo = new wwImageInfo();
				
				loInfo.Width = loBMP.Width;
				loInfo.Height = loBMP.Height;
				loInfo.HorizontalPixelResolution = loBMP.HorizontalResolution;
				loInfo.VerticalPixelResolution = loBMP.VerticalResolution;

				loBMP.Dispose();

				return loInfo;
			}
			catch(Exception ex) 
			{			
				this.SetError(ex.Message); 
			}

			return null;
		}

		public Bitmap GetImageInfoBitmap(string lcImageFile)
		{
			try 
			{
				Bitmap loBMP = new Bitmap(lcImageFile);
				
				wwImageInfo loInfo = new wwImageInfo();
				
				loInfo.Width = loBMP.Width;
				loInfo.Height = loBMP.Height;
				loInfo.HorizontalPixelResolution = loBMP.HorizontalResolution;
				loInfo.VerticalPixelResolution = loBMP.VerticalResolution;

				return loBMP;
			}
			catch(Exception ex) 
			{			
				this.SetError(ex.Message); 
			}

			return null;
		}
		
		
		/// <summary>
		///  Sets the error properties of the object
		/// </summary>
		/// <param name="lcError"></param>
		protected void SetError(string lcError) 
		{
			if (lcError.Length == 0)  
			{
				this.cErrorMsg = "";
				this.bError = false;
			}
			else 
			{
				this.cErrorMsg = lcError;		
				this.bError = true;
			}
		}

		
	}

	[ClassInterface(ClassInterfaceType.AutoDual)]
	public class wwImageInfo 
	{
		public int Height = 0;
		public int Width = 0;
		public float HorizontalPixelResolution = 0;
		public float VerticalPixelResolution = 0;
	}
}
