using System;
using System.IO;
using System.Data;
using System.Data.SqlClient;

using System.Reflection;
using System.Xml;

using System.Runtime.InteropServices;
using Westwind.Tools;

namespace DotNetCOM
{
	/// <summary>
	/// DotNetCom sample COM exposed COM object
	/// </summary>

	[ClassInterface(ClassInterfaceType.AutoDual)]
    [ProgId("DotNetCom.DotNetComPublisher")]	
	public class DotNetComPublisher
	{
		public string cConnectionString =  "server=(local);database=pubs;uid=sa;pwd=wwind"; 

		protected string cName = "";
		public string Name 
		{
			get { return this.cName; }
			set { this.cName = value; }
		}
		public string cErrorMsg = "";
		public string ErrorMsg{
			get {return this.cErrorMsg; }
			set { this.cErrorMsg = value; }
		}
		protected bool bError = false;
		public bool Error
		{
			get {return this.bError; }
			set { this.bError = value; }
		}

		public DataSet oDs;

		public DotNetComPublisher()
		{
		}

		/// <summary>
		/// Your standard HelloWorld test method.
		/// </summary>
		/// <param name="Name">Name of the user</param>
		/// <returns></returns>
		public string HelloWorld(string Name) 
		{
			return "Hello " + Name + " at " + DateTime.Now.ToShortTimeString();
		}

		public DateTime GetServerTime() 
		{
			return DateTime.Now;
		}

		public decimal AddNumbers(decimal lnNumber1, decimal lnNumber2) 
		{
			return lnNumber1 + lnNumber2;	
		}

		
		public System.Data.DataSet GetAuthorData(string lcName)
		{

			if (lcName == "" )
				lcName = "%";

			DataSet ds = new DataSet();

			string cConnection = this.cConnectionString;
			SqlConnection	oConn = new SqlConnection(cConnection);
			
			SqlDataAdapter oAdapter = new SqlDataAdapter();
			oAdapter.SelectCommand = 
				new SqlCommand("select * from Authors where au_lname like '" + lcName + "%' ORDER BY au_lname",oConn);
	            
			try 
			{
				oConn.Open();
			}
			catch(Exception e) 
			{
				this.cErrorMsg = e.Message;
				this.bError = true;
				return null;
			}

			try 
			{
				oAdapter.Fill(ds,"Authors");
			}
			catch (Exception e) 
			{
				this.cErrorMsg = e.Message;
				this.bError = true;
				return null;
			}
			
			oConn.Close();

			this.oDs = ds;

			return ds;
		}
		public System.Data.DataSet GetAuthorData() 
		{
			return this.GetAuthorData("");
		}


		public string GetAuthorDataXml(string lcName) 
		{
			DataSet loDs = this.GetAuthorData(lcName);
			if (loDs == null)
				return "";
			
			StringWriter loWriter = new StringWriter();
			loDs.WriteXml(loWriter,XmlWriteMode.WriteSchema);
			return loWriter.ToString();
		}

		public bool UpdateAuthorDataXml(string lcXml) 
		{
			this.SetError("");

			DataSet loDs = new DataSet();

			loDs.ReadXml(new StringReader(lcXml),XmlReadMode.DiffGram);

			string cConnection = this.cConnectionString;
			SqlConnection	oConn = new SqlConnection(cConnection);
			
			SqlDataAdapter oAdapter = new SqlDataAdapter();
			oAdapter.SelectCommand = 
				new SqlCommand("select * from Authors",oConn);

			try 
			{
				// *** Create the Update/Insert Commands
				SqlCommandBuilder oCmdBuilder = new SqlCommandBuilder(oAdapter);
				oAdapter.Update(loDs,"Authors");
			}
			catch (Exception ex)
			{
				this.SetError(ex.Message);
				return false;
			}

			return true;
		}


		public bool UpdateAuthorData(DataSet loDs)
		{
			this.SetError("");

			string cConnection = this.cConnectionString;
			SqlConnection	oConn = new SqlConnection(cConnection);
			
			SqlDataAdapter oAdapter = new SqlDataAdapter();
			oAdapter.SelectCommand = 
				new SqlCommand("select * from Authors",oConn);

			try 
			{
				// *** Create the Update/Insert Commands
				SqlCommandBuilder oCmdBuilder = new SqlCommandBuilder(oAdapter);
				oAdapter.Update(loDs,"Authors");
			}
			catch (Exception ex)
			{
				this.SetError(ex.Message);
				return false;
			}

			return true;
		}

		public byte[] GetBinaryFile(string lcFile) 
		{
			byte[] lcResult = null;

			try 
			{
				FileStream loStream = new FileStream(lcFile,FileMode.Open);
				loStream.Read(lcResult,0,(int) loStream.Length);
				loStream.Close();
			}
			catch(Exception) 
			{
				return null;
			}
			return lcResult;
		}

		public string[] GetStrings() 
		{
			string[] strings = new string[3];
			strings[1] = "Rick";
			strings[2] = "Strahl";
			strings[0] = "Test";

			return strings;
		}


		/// <summary>
		/// Pass a VFP style record. Field must have a "Company" field
		/// </summary>
		/// <param name="loObject"></param>
		/// <returns></returns>
		public string PassRecordObject(object loObject) 
		{
			return (string) ComUtils.GetProperty(loObject,"Company");
		}


		/// <summary>
		/// Return a simple 'static' Customer Object.
		/// </summary>
		/// <returns></returns>
		public Customer ReturnCustomer()
		{
			Customer loCust = new Customer();

			loCust.Name = "Rick Strahl";
			loCust.Company = "West Wind";
			loCust.oAddress.StreetAddress = "32 Kaiea Place\r\nPaia, HI 96779";
			loCust.oAddress.Phone = "808 579-1234";
			loCust.CreditLimit = (decimal) 10000.50;

			return loCust;
		}


		/// <summary>
		/// Returns a customer object based on a company name.
		/// </summary>
		/// <param name="lcCompany"></param>
		/// <returns></returns>
		public Customer GetCustomerObject(string lcCompany)
		{

			DataSet ds = new DataSet();

			string cConnection = this.cConnectionString;
			SqlConnection	oConn = new SqlConnection(cConnection);
			
			SqlDataAdapter oAdapter = new SqlDataAdapter();
			oAdapter.SelectCommand = 
				new SqlCommand("select * from wws_customers where company like '" + lcCompany + "%'",oConn);
	            
			try 
			{
				oConn.Open();
			}
			catch(Exception e) 
			{
				this.cErrorMsg = e.Message;
				this.bError = true;
				return null;
			}

			try 
			{
				oAdapter.Fill(ds,"Customer");
			}
			catch (Exception e) 
			{
				this.cErrorMsg = e.Message;
				this.bError = true;
				return null;
			}
			
			oConn.Close();

			if (ds.Tables["Customer"].Rows.Count < 1 )
			{
				return null;
			}

			Customer loCust = new Customer();
			DataRow loRow = ds.Tables["Customer"].Rows[0];

			loCust.Name = loRow["FirstName"].ToString().Trim() + " " + loRow["LastName"].ToString();
			loCust.Company = loRow["Company"].ToString();
			loCust.oAddress.StreetAddress = loRow["Address"].ToString();
			loCust.oAddress.Phone = loRow["Phone"].ToString();
			loCust.oAddress.Email = loRow["Email"].ToString();
			loCust.Entered = (DateTime) loRow["Entered"];
		
			return loCust;
		}


		private void SetError(string lcError) 
		{
			if (lcError != null && lcError.Length > 0) 
			{
				this.cErrorMsg = lcError;
				this.bError = true;
			}
			else 
			{
				this.cErrorMsg = "";
				this.bError = false;
			}
		}

		
	}


	[ClassInterface(ClassInterfaceType.AutoDual)]
	public class Customer
	{
		public string Name = "";
		public string Company = "";
		public decimal CreditLimit = (decimal) 0.00;
		public DateTime Entered = DateTime.Now;
		public Address oAddress = null;

		public Customer()
		{
			this.oAddress = new Address();
		}
	}

	[ClassInterface(ClassInterfaceType.AutoDual)]
 	public class Address
	{
		public string StreetAddress = "";
		public string Phone = "";
		public string Email = "";
	}
}

 
