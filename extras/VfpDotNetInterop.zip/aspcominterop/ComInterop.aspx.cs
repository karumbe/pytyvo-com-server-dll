using System;
using System.Collections;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Web;
using System.Web.SessionState;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Web.UI.HtmlControls;

using System.Data.SqlClient;
using System.Xml;
using System.IO;
using System.Reflection;

/// Our COM object reference
/// Note: Make sure a reference is added too!!!
using aspdemos;


namespace ASPInterOp
{
	/// <summary>
	/// Summary description for ComInterop.
	/// </summary>
	public class ComInterop : System.Web.UI.Page
	{
		protected System.Web.UI.WebControls.TextBox txtCounterName;
		protected System.Web.UI.WebControls.Button btnIncrement;
		protected System.Web.UI.WebControls.Button btnDelete;
		protected System.Web.UI.WebControls.Button btnShowAll;
		protected System.Web.UI.WebControls.Label Label1;
		protected System.Web.UI.WebControls.Label lblCounter;
		protected System.Web.UI.WebControls.Label lblErrorMsg;
		protected System.Web.UI.WebControls.Label Label2;
		protected System.Web.UI.WebControls.Button btnObject2;
		protected System.Web.UI.WebControls.Button btnObjectContext;
		protected System.Web.UI.WebControls.Button btnDataSet;
		protected System.Web.UI.WebControls.DataGrid oGrid;
		protected System.Web.UI.WebControls.Button btnDataSetToXML;
		protected System.Web.UI.WebControls.Button btnCOMDataSet;
		protected System.Web.UI.WebControls.Label lblCounterList;

		public string cConnectionString = "server=(local);database=pubs;uid=sa;pwd=wwind"; 

		private void Page_Load(object sender, System.EventArgs e)
		{
			if (!this.IsPostBack) 
			{
				this.btnIncrement_Click(this,e);
			}
		}

		#region Web Form Designer generated code
		override protected void OnInit(EventArgs e)
		{
			//
			// CODEGEN: This call is required by the ASP.NET Web Form Designer.
			//
			InitializeComponent();
			base.OnInit(e);
		}
		
		/// <summary>
		/// Required method for Designer support - do not modify
		/// the contents of this method with the code editor.
		/// </summary>
		private void InitializeComponent()
		{    
			this.btnShowAll.Click += new System.EventHandler(this.btnShowAll_Click);
			this.btnDelete.Click += new System.EventHandler(this.btnDelete_Click);
			this.btnIncrement.Click += new System.EventHandler(this.btnIncrement_Click);
			this.btnObjectContext.Click += new System.EventHandler(this.btnObjectContext_Click);
			this.btnDataSetToXML.Click += new System.EventHandler(this.btnDataSetToXML_Click);
			this.btnDataSet.Click += new System.EventHandler(this.btnDataSet_Click);
			this.btnObject2.Click += new System.EventHandler(this.btnObject2_Click);
			this.btnCOMDataSet.Click += new System.EventHandler(this.btnCOMDataSet_Click);
			this.Load += new System.EventHandler(this.Page_Load);

		}
		#endregion

		private void btnIncrement_Click(object sender, System.EventArgs e)
		{
			aspdemos.ASPToolsClass oVFP = new ASPToolsClass();
			this.lblCounter.Text =  oVFP.IncCounter(this.txtCounterName.Text,0).ToString();
			this.lblErrorMsg.Text = oVFP.CERRORMSG.ToString(); 
		
		}

		private void btnDelete_Click(object sender, System.EventArgs e)
		{
			ASPToolsClass oVFP = new ASPToolsClass();
			object loVFP = oVFP.GetDebugInstance();

			oVFP.DeleteCounter(this.txtCounterName.Text);
			this.lblErrorMsg.Text = "Counter " + this.txtCounterName.Text + " deleted...";
			this.lblCounter.Text = "";
		}

		private void btnShowAll_Click(object sender, System.EventArgs e)
		{
			ASPToolsClass oVFP = new ASPToolsClass();
			this.lblCounterList.Text = "<small><center>Note: To refresh this list click the Show All button</center></small>" +
								 	oVFP.ShowCounters();
			this.lblErrorMsg.Text = oVFP.CERRORMSG.ToString();	
		}

		private void btnObject2_Click(object sender, System.EventArgs e)
		{
			ASPToolsClass oVFP = new ASPToolsClass();
			object loCustomer =  oVFP.ReturnObject("aspCustomer");

		// string lcCompany =  loCustomer.GetType().InvokeMember("Load",
		//		BindingFlags.InvokeMethod,null,loCustomer,new object[] {"4"}).ToString();

			string lcCompany;
			if ( (bool) ComUtils.CallMethod(loCustomer,"Load","4") ) 
			{

				// *** Retrieve oData Member first
				object loData = ComUtils.GetProperty(loCustomer,"ODATA");

				// *** Then retrieve the Company
				lcCompany = (string) ComUtils.GetProperty(loData,"COMPANY");

				// *** The easiest way is this:
				//lcCompany = (string) this.GetPropertyEx(loCustomer,"oData.Company");
			}
			else 
			{
				lcCompany = "n/a";
			}

			this.lblErrorMsg.Text = lcCompany;
		}
		


		private void btnObjectContext_Click(object sender, System.EventArgs e)
		{
			ASPToolsClass oVFP = new ASPToolsClass();

			//object loVfp = oVFP.GetDebugInstance();
			ComUtils.CallMethod(oVFP,"ASPObjects");

			oVFP.ASPObjects();
			this.lblCounter.Text = "";

			// this.lblErrorMsg.Text = oVFP.CERRORMSG.ToString();
		}

		/// <summary>
		/// Retrieves an XML string from a VFP COM object and creates
		/// a DataSet from it, then binds it to a datagrid dynamically.
		/// </summary>
		/// <param name="sender"></param>
		/// <param name="e"></param>
		private void btnDataSet_Click(object sender, System.EventArgs e)
		{
			ASPToolsClass oVFP = new ASPToolsClass();

			/// Retrieve the customer list
			string lcXML = oVFP.XMLCustList("");
				
			DataSet loDS = new DataSet();

			try 
			{ 
				loDS.ReadXml( new StringReader(lcXML) );
			}
			catch(Exception ex) 
			{
				this.lblErrorMsg.Text = ex.Message;
				return;
			}
			
			this.oGrid.DataSource = loDS.Tables[0];
			this.oGrid.DataBind();			
		}

		/// <summary>
		/// Creates a DataSet in ASP.NET code and passes the DataSet
		/// in XML format to the Visual FoxPro COM object. The object
		/// picks up the XML parses it into a cursor, then generates
		/// an HTML response that's displayed in a label.
		/// </summary>
		/// <param name="sender"></param>
		/// <param name="e"></param>
		private void btnDataSetToXML_Click(object sender, System.EventArgs e)
		{
			string lcID = "%";

			DataSet ds = new DataSet();

			string cConnection = this.cConnectionString;
			SqlConnection	oConn = new SqlConnection(cConnection);
			
			SqlDataAdapter oAdapter = new SqlDataAdapter();
			oAdapter.SelectCommand = 
				new SqlCommand("select * from Authors where au_id like '" + lcID + "%'",oConn);
	            
			oConn.Open();

			oAdapter.Fill(ds,"authors");

			oConn.Close();


			// now pass the XML to the VFP app
			ASPToolsClass oVFP = new ASPToolsClass();

			// StringWriter receives the output XML stream
			StringWriter loWriter = new StringWriter();

			// Note you have to write with Schema in order for XMLAdapter to be able
			// to process the table.
			ds.WriteXml( loWriter,XmlWriteMode.WriteSchema );

			//ds.WriteXml( @"d:\temp\authors.xml",XmlWriteMode.WriteSchema);

			// *** Output HTML Table to the label
			this.lblCounterList.Text = oVFP.XMLDataSet(loWriter.ToString(),"authors");
			
			//this.lblCounterList.Text  = (string) this.CallMethod(oDebug,"XMLDataSet",loWriter.ToString(),"authors");
			//this.lblCounterList.Text  = (string) oVFP.CERRORMSG;
		}

		private void btnCOMDataSet_Click(object sender, System.EventArgs e)
		{
			string lcID = "%";

			DataSet ds = new DataSet();

			string cConnection = this.cConnectionString;
			SqlConnection	oConn = new SqlConnection(cConnection);
			
			SqlDataAdapter oAdapter = new SqlDataAdapter();
			oAdapter.SelectCommand = 
				new SqlCommand("select * from Authors where au_id like '" + lcID + "%'",oConn);
	            
			oConn.Open();

			oAdapter.Fill(ds,"authors");

			oConn.Close();


			// now pass the XML to the VFP app
				ASPToolsClass oVFP = new ASPToolsClass();

			this.lblCounterList.Text = oVFP.COMDataSet(ds);

		}	
	}

	public class Customer 
	{
		public string cName = "Rick Strahl";
		public string cAddress = "32 Kaiea Place";
	}
}
