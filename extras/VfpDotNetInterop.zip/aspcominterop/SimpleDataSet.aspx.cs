using System;
using System.Collections;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Web;
using System.Web.SessionState;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Web.UI.HtmlControls;

using System.Data.OleDb;


namespace ASPInterOp
{
	/// <summary>
	/// Summary description for SimpleDataSet.
	/// </summary>
	public class SimpleDataSet : System.Web.UI.Page
	{
		OleDbConnection oConn = null;
		DataSet oDS = null;

		protected System.Web.UI.WebControls.DataGrid oCustList;
		protected System.Web.UI.WebControls.Label lblErrorMsg;
		protected System.Web.UI.WebControls.TextBox txtCustomer;
		protected System.Web.UI.WebControls.Button btnFilter;

		private void Page_Load(object sender, System.EventArgs e)
		{
			this.btnFilter_Click(this,new System.EventArgs());
		}

		private bool GetCustomerList(string lcCompanyFilter, string lcCursor)
		{
			// Put user code to initialize the page here
			this.oConn = new OleDbConnection("Provider=vfpoledb.1;" + 
		    	@"Data Source=D:\Programs\vfp70\Samples\Data\testdata.dbc;");

			try {
				this.oConn.Open();
			}
			catch(Exception ex) 
			{
				this.lblErrorMsg.Text = ex.Message;
				return false;
			}

			string lcSQL = "select company, contact, city, maxordamt from customer " + 
						   " where company like '" + lcCompanyFilter +"%'" + 
						   " order by company";

			OleDbDataAdapter oAdapter = new OleDbDataAdapter(lcSQL,this.oConn);

			if (this.oDS == null) 
			{
				this.oDS = new DataSet();
			}

			try 
			{
				oAdapter.Fill(this.oDS,lcCursor);
			}
			catch(Exception ex)
			{
				this.lblErrorMsg.Text = ex.Message;
				return false;
			}
			finally
			{ 
				this.oConn.Close();
			}

			return true;
		}

		#region Web Form Designer generated code
		override protected void OnInit(EventArgs e)
		{
			//
			// CODEGEN: This call is required by the ASP.NET Web Form Designer.
			//
			InitializeComponent();
			base.OnInit(e);
		}
		
		/// <summary>
		/// Required method for Designer support - do not modify
		/// the contents of this method with the code editor.
		/// </summary>
		private void InitializeComponent()
		{    
			this.btnFilter.Click += new System.EventHandler(this.btnFilter_Click);
			this.Load += new System.EventHandler(this.Page_Load);

		}
		#endregion

		private void btnFilter_Click(object sender, System.EventArgs e)
		{
			if ( this.GetCustomerList(this.txtCustomer.Text,"CustomerList") )
			{
				if (this.oDS.Tables["CustomerList"].Rows.Count > 0) 
				{
					// ***  Demonstrates accessing individual values
					decimal MaxOrdAmt = (decimal) this.oDS.Tables["CustomerList"].Rows[0]["maxordamt"];
					string Company = (string) this.oDS.Tables["CustomerList"].Rows[0]["company"];
				}

				// *** Databind to the DataGrid
				this.oCustList.DataSource = this.oDS.Tables["CustomerList"];
				this.oCustList.DataBind();
			}
		}
	}
}
