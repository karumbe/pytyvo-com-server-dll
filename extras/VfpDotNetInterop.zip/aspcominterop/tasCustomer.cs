using System;
using System.Data;
using System.Data.OleDb;

using System.Text;

namespace ASPInterOp
{
	/// <summary>
	/// Summary description for tasCustomer.
	/// </summary>
	public class tasCustomer : aBusObj
	{
		public tasCustomer()
		{
			this.cConnectString = @"Provider=vfpoledb.1;Data Source=D:\Programs\vfp70\Samples\Data\testdata.dbc;Exclusive=1;Nulls=1";
		}

		protected override bool Open()
		{
			if (base.Open()) 
			{
				try 
				{
					OleDbCommand oCommand = new OleDbCommand();
					oCommand.Connection = this.oConn;
					oCommand.CommandText = "SET NULL OFF\r\nSET DELETED ON";
					oCommand.ExecuteNonQuery();
				}
				catch(Exception ex) 
				{
					this.SetError(ex.Message);
					return false;
				}
				return true;
			}

			return false;
		}

		public bool LoadCustomer(string lcID)
		{

			int lnCount = this.Execute("select * from customer where cust_id='" + lcID + "'","Customer");
			if (this.lError) 
			{
				return false;
			}

			return true;
		}

		public bool SaveCustomer()
		{

			if (!this.Open()) 
			{
				return false;
			}

			OleDbDataAdapter oDSAdapter = new OleDbDataAdapter("select * from customer",this.oConn);

			/// This builds the Update/InsertCommands for the data adapter
			/// NOTE: THIS DOESN'T WORK WITH THE VFP 7 OleDb Driver
			//OleDbCommandBuilder oCmdBuilder = new OleDbCommandBuilder(oDSAdapter);
			//oDSAdapter.UpdateCommand = oCmdBuilder.GetUpdateCommand();

			
			/// So instead we have to manually build our update statement
			/// *or* we can simply issue the Update command directly over a connection
			DataRow oRow = this.oDS.Tables["Customer"].Rows[0];

			string lcPhone = oRow["Phone"].ToString();

			string lcSQL = 
				"UPDATE customer " + 
				"SET company='" + oRow["company"].ToString() + "'," +
				    "contact='" + oRow["contact"].ToString() + "'," +     
                    "address='" + oRow["address"].ToString() + "'," +     
				    "city='" + oRow["city"].ToString() + "', " +     
                    "region='" + oRow["region"].ToString() + "', " +     
				    "postalcode='" + oRow["postalcode"].ToString() + "'," +     
				    "country='" + oRow["country"].ToString() + "'," +     
					"phone='" + oRow["phone"].ToString() + "'," +
				    "maxordamt=" + oRow["maxordamt"].ToString() + " " +     
				"where cust_id='" +oRow["cust_id"]+ "'";

			oDSAdapter.UpdateCommand =  new OleDbCommand(lcSQL,this.oConn);

			int lnRows = 0;
			try 
			{
				/// Take the changes in the dataset and sync to the database
				lnRows = oDSAdapter.Update(this.oDS,"Customer");
				//oDSAdapter.UpdateCommand.ExecuteNonQuery();

			}
			catch(Exception e)
			{
				this.cErrormsg = e.Message;
				return false;
			}

			return true;
		}
		
		public bool AddCustomer(string lcCompany, string lcContact, decimal lnMaxOrdAmt)
		{

			if (!this.Open()) 
			{
				return false;
			}

			OleDbCommand oCommand = new OleDbCommand();
			oCommand.Connection = this.oConn;

			// C#
			// The following two properties can be set in the Properties window
			// but are shown here for completeness.
			oCommand.CommandText = "InsertCustomer('" + lcCompany + "','" + lcContact + "',1600.00)";

//			/// *** THIS CODE DOES NOT WORK
//			oCommand.CommandText = "InsertCustomer";
//			oCommand.CommandType = System.Data.CommandType.StoredProcedure;
//			
//			
//			oCommand.Parameters.Add("lcCompany",OleDbType.Char);
//			oCommand.Parameters["lcCompany"].Value = lcCompany;
//			oCommand.Parameters.Add("lcContact",OleDbType.Char);
//			oCommand.Parameters["lcContact"].Value = lcContact;
//			oCommand.Parameters.Add("lnMaxOrdAmt",OleDbType.Currency );
//			oCommand.Parameters["lnMaxOrdAmt"].Value = lnMaxOrdAmt;

			try 
			{
				oCommand.ExecuteNonQuery();
			}
			catch(Exception ex)
			{
				this.SetError(ex.Message);
				return false;
			}
			
			return true;
		}


		public bool DeleteCustomer(string lcId)
		{

			int lnResult = this.ExecuteNonQuery("delete from customer where cust_id='" + lcId +"'");

			if (lnResult == -1)
			   return false;

			return true;
		}
	}

	public class aBusObj
	{
		public string cConnectString =	"";

		/// these properties along with Open,Close,Load,Save really belong
		/// into a data wrapper or high level business object. For compactness'
		/// sake I've included them as part of the class here.
		public OleDbConnection oConn		=	null;
		public DataSet	oDS					=   null;
		public string cErrormsg				=   "";
		public bool lError					=   false;


		public aBusObj()
		{
		}

		/// *********************
		/// DATA UTILITY ROUTINES	
		/// *********************
		/// these are not exposed throught the Web Service
		/// and really belong into an external class.	


		/// <summary>
		/// Sets up the connection for a query
		/// </summary>
		/// <returns></returns>
		protected virtual bool Open()
		{
			/// create if it doesn't exist already
			if (this.oConn == null) 
			{
				try 
				{
					this.oConn = new OleDbConnection(this.cConnectString);
				}
				catch(Exception e)
				{
					this.SetError( e.Message );
					return false;
				}
			}

			/// check if connection is open - if not open it
			if (this.oConn.State != ConnectionState.Open) 
			{
				try 
				{
					oConn.Open();
				}
				catch(Exception e)
				{
					this.SetError( e.Message );
					return false;
				}
			}

			/// make sure our dataset object exists
			if (oDS == null) 
				oDS = new DataSet();

			return true;
		}

		protected virtual bool Close() 
		{
			if (oConn.State == ConnectionState.Open)
				try 
				{
					oConn.Close();
				}
				catch(Exception e)
				{
					this.SetError( e.Message );
					return false;
				}

			return true;
		}

		/// <summary>
		///  Executes a Select statement that returns a cursor.
		/// </summary>
		/// <param name="lcSQL"></param>
		/// <param name="lcCursor"></param>
		/// <returns></returns>
		public virtual int Execute(string lcSQL, string lcCursor)
		{
			if (!this.Open()) 
				return 0;

			OleDbDataAdapter oDSAdapter = new OleDbDataAdapter();
			oDSAdapter.SelectCommand = 
				new OleDbCommand(lcSQL,oConn);

			//oDSAdapter.FillSchema(oDS,SchemaType.Mapped,lcCursor);


			/// remove the table if it exists - fail and ignore
			try 
			{
				oDS.Tables.Remove(lcCursor);
			}
			catch(Exception) { }  // Ignore the error
	
			try 
			{
				oDSAdapter.Fill(oDS,lcCursor);
			}
			catch(Exception e)
			{
				this.SetError(e.Message);
				return 0;
			}

			return oDS.Tables[lcCursor].Rows.Count;
		}

		public virtual int ExecuteNonQuery(string lcCommand)
		{
			if (!this.Open()) 
				return -1;

			OleDbCommand oCommand = new OleDbCommand(lcCommand,this.oConn);

			int lnResult;
			try 
			{
				lnResult = oCommand.ExecuteNonQuery();
			}
			catch(Exception ex)
			{
				this.cErrormsg = ex.Message;
				return -1;
			}

			return lnResult;
		}

		protected virtual void SetError(string lcErrormsg)
		{
			if (lcErrormsg.Length == 0) 
			{
				cErrormsg = "";
				lError = false;
				return;
			}

			cErrormsg = lcErrormsg;
			lError = true;
		}
	}
}
