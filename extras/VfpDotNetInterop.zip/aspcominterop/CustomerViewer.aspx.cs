using System;
using System.Collections;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Web;
using System.Web.SessionState;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Web.UI.HtmlControls;
using System.IO;

/// our COM object instance
/// Note: Must be added as a reference as well
using aspdemos;

namespace ASPInterOp
{
	/// <summary>
	/// Summary description for CustomerViewer.
	/// </summary>
	public class CustomerViewer : System.Web.UI.Page
	{
		protected System.Web.UI.WebControls.Label lblErrorMsg;
		protected System.Web.UI.WebControls.TextBox txtCompany;
		protected System.Web.UI.WebControls.TextBox txtName;
		protected System.Web.UI.WebControls.TextBox txtPhone;
		protected System.Web.UI.WebControls.TextBox txtAddress;
		protected System.Web.UI.WebControls.TextBox txtEmail;
		protected System.Web.UI.WebControls.TextBox txtBillRate;
		protected System.Web.UI.WebControls.DataGrid oCustList;
		protected System.Web.UI.WebControls.Button btnSave;
		
		public object oCustomer;
	

		private void Page_Load(object sender, System.EventArgs e)
		{
			// Put user code to initialize the page here
			this.LoadGrid();

			string lcAction = Request.QueryString["Action"];
			bool llSaving = Request.Form["btnSave"] == null ? false : true;

			if (lcAction == null) 
			{
				lcAction = "";
			}
			if (lcAction == "Edit" && !llSaving)
			{
				this.LoadCustomer( Request.QueryString["Id"] );
				this.btnSave.Enabled = true;
			}
			else
				this.btnSave.Enabled = false;
		}

		/// <summary>
		/// Loads a list of customers from the COM object via XML and 
		/// then databinds it to the datagrid on the form
		/// </summary>
		void LoadGrid() 
		{
			aspdemos.ASPToolsClass oVFP = new ASPToolsClass();
			object loCustomer = oVFP.ReturnObject("aspCustomer");

			string lcXml = (string) ComUtils.CallMethod(loCustomer,"CustomerListXML","");

			DataSet loDS = new DataSet();

			try 
			{ 
				loDS.ReadXml( new StringReader(lcXml) );
			}
			catch(Exception ex) 
			{
				this.lblErrorMsg.Text = ex.Message;
				return;
			}
			
			this.oCustList.DataSource = loDS.Tables[0];
			this.oCustList.DataBind();			
		}

		/// <summary>
		/// Loads a customer from the business object and databinds it
		/// </summary>
		/// <param name="lcCustno"></param>
		void LoadCustomer(string lcCustno) 
		{
			if (lcCustno == null)
					return;

			aspdemos.ASPToolsClass oVFP = new ASPToolsClass();
			//object oVFP = oxVFP.GetDebugInstance();

			object loCustomer = oVFP.ReturnObject("aspCustomer");
			//object loCustomer = ComUtils.CallMethod(oVFP,"ReturnObject","aspCustomer");

			bool llResult = (bool) ComUtils.CallMethod(loCustomer,"Load",lcCustno.Trim());
			if (!llResult) 
			{
				this.lblErrorMsg.Text = "Couldn't load customer";
				return;
			}

			this.oCustomer = loCustomer;

			this.DataBind();

			// oxVFP.CloseDebugInstance();
		}

		#region Web Form Designer generated code
		override protected void OnInit(EventArgs e)
		{
			//
			// CODEGEN: This call is required by the ASP.NET Web Form Designer.
			//
			InitializeComponent();
			base.OnInit(e);
		}
		
		/// <summary>
		/// Required method for Designer support - do not modify
		/// the contents of this method with the code editor.
		/// </summary>
		private void InitializeComponent()
		{    
			this.btnSave.Click += new System.EventHandler(this.btnSave_Click);
			this.Load += new System.EventHandler(this.Page_Load);

		}
		#endregion

		/// <summary>
		/// Saves the current customer in the window
		/// </summary>
		/// <param name="sender"></param>
		/// <param name="e"></param>
		private void btnSave_Click(object sender, System.EventArgs e)
		{

			string lcCustno = Request.QueryString["id"];

			aspdemos.ASPToolsClass oxVFP = new ASPToolsClass();
			object oVFP = oxVFP.GetDebugInstance();

			//object loCustomer = oVFP.ReturnObject("aspCustomer");
			
			object loCustomer = ComUtils.CallMethod(oVFP,"ReturnObject","aspCustomer");

			bool llResult = (bool) ComUtils.CallMethod(loCustomer,"Load",lcCustno.Trim());
			if (!llResult) 
			{
				this.lblErrorMsg.Text = "Couldn't load customer";
				return;
			}

			ComUtils.SetPropertyEx(loCustomer,"oData.CareOf",this.txtName.Text);
			
			this.oCustomer = loCustomer;

			// *** A little easier
			this.SetProperty("oData.Company",this.txtCompany.Text);
			this.SetProperty("oData.Address",this.txtAddress.Text);
			this.SetProperty("oData.Phone",this.txtPhone.Text);
			this.SetProperty("oData.Email",this.txtEmail.Text);
			this.SetProperty("oData.BillRate",Convert.ToDecimal( this.txtBillRate.Text ) );

			llResult = (bool) ComUtils.CallMethod(loCustomer,"Save");

			this.DataBind();

			oxVFP.CloseDebugInstance();
		}

		/// <summary>
		/// Retrieves an oCustomer property used for databinding
		/// </summary>
		/// <param name="lcProperty"></param>
		/// <returns></returns>
		public object GetProperty(string lcProperty) 
		{
			return ComUtils.GetPropertyEx(this.oCustomer,lcProperty);
		}

		/// <summary>
		/// Sets an oCustomer Property - shortcut to make for less code.
		/// </summary>
		/// <param name="lcProperty"></param>
		/// <param name="loValue"></param>
		public void SetProperty(string lcProperty,params object[] loValue) 
		{
			ComUtils.SetPropertyEx(this.oCustomer,lcProperty,loValue);
		}
	}
}
