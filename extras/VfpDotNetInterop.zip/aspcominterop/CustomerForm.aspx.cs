using System;
using System.Collections;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Web;
using System.Web.SessionState;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Web.UI.HtmlControls;

namespace ASPInterOp
{
	/// <summary>
	/// Summary description for CustomerForm.
	/// </summary>
	public class CustomerForm : System.Web.UI.Page
	{
		public tasCustomer oCustomer;

		public DataRow dtrCurrent; 
		
		protected System.Web.UI.WebControls.ListBox oCustomerList;
		protected System.Web.UI.WebControls.Label lblErrorMessage;
		protected System.Web.UI.WebControls.TextBox txtCompany;
		protected System.Web.UI.WebControls.TextBox txtAddress;
		protected System.Web.UI.WebControls.TextBox txtCity;
		protected System.Web.UI.WebControls.TextBox txtState;
		protected System.Web.UI.WebControls.TextBox txtZip;
		protected System.Web.UI.WebControls.TextBox txtCountry;
		protected System.Web.UI.WebControls.TextBox txtPhone;
		protected System.Web.UI.WebControls.Button btnSave;
		protected System.Web.UI.WebControls.Button cmdAdd;
		protected System.Web.UI.WebControls.TextBox txtContact;
		protected System.Web.UI.WebControls.Image Image1;
		protected System.Web.UI.WebControls.Button btnDelete;
		protected System.Web.UI.WebControls.TextBox txtCredit;

		private void Page_Load(object sender, System.EventArgs e)
		{

			// Put user code to initialize the page here
			this.lblErrorMessage.Text = "";

			this.oCustomer = new tasCustomer();

			if (!this.IsPostBack) 
			{
				if (this.LoadCustomerList()) {
					// *** Force first item to display in edit view
					if (this.oCustomerList.Rows > 0) 
					{
						this.oCustomerList.SelectedIndex = 0;
						this.ShowCustomer();
					}
				}

			}

			this.InitializeComponent();
		}

		private void InitializeComponent()
		{
			this.oCustomerList.SelectedIndexChanged += new System.EventHandler(this.oCustomerList_SelectedIndexChanged);
			this.btnSave.Click += new System.EventHandler(this.btnSave_Click);
			this.cmdAdd.Click += new System.EventHandler(this.cmdAdd_Click);
			this.btnDelete.Click += new System.EventHandler(this.btnDelete_Click);
			this.Load += new System.EventHandler(this.Page_Load);

		}

		protected bool LoadCustomerList()
		{
			int lnCount = oCustomer.Execute("select company, cust_id from customer order by Company",
                                            "customer");

			if (this.oCustomer.lError)  
			{
				this.lblErrorMessage.Text = oCustomer.cErrormsg;
				return false;
			}
			else 
			{
				this.oCustomerList.DataSource = oCustomer.oDS.Tables["customer"];
				this.oCustomerList.DataTextField = "company";
				this.oCustomerList.DataValueField = "cust_id";
				this.oCustomerList.DataBind();
			}

			return true;
		}

		private void oCustomerList_SelectedIndexChanged(object sender, System.EventArgs e)
		{
			this.ShowCustomer();
		}

		private bool ShowCustomer()
		{
			string lcID = this.GetIdFromList();

			if ( lcID == null || lcID == "" )
				 return false;

			if ( !this.oCustomer.LoadCustomer(lcID) )
			{
				this.lblErrorMessage.Text = this.oCustomer.cErrormsg;
				return false;
			}


			// *** Force the Server Control fields to databind
			this.dtrCurrent  = this.oCustomer.oDS.Tables["Customer"].Rows[0];
			this.DataBind();

			// *** For some reason the auto-binding doesn't work right with this value
			this.txtCredit.Text =  this.dtrCurrent["MaxOrdAmt"].ToString();


			return true;
		}


		private void btnSave_Click(object sender, System.EventArgs e)
		{
			string lcID;

			if (this.oCustomerList.SelectedItem == null) {
				this.lblErrorMessage.Text = "No customer selected";
				return;
			}	

			lcID = this.oCustomerList.SelectedItem.Value;

			if	( !this.oCustomer.LoadCustomer(lcID) )  
			{
				this.lblErrorMessage.Text = oCustomer.cErrormsg;
				return;
			}
			
			/// Update the DataRow of the Customer Table
			DataRow oRow  = this.oCustomer.oDS.Tables["Customer"].Rows[0];
			oRow["company"] = this.txtCompany.Text;
			oRow["contact"] = this.txtContact.Text;
			oRow["address"] = this.txtAddress.Text;
			oRow["city"] = this.txtCity.Text;
			oRow["region"] = this.txtState.Text;
			oRow["postalcode"] = this.txtZip.Text;
			oRow["country"] = this.txtCountry.Text;
			oRow["phone"] = this.txtPhone.Text;
			oRow["MaxOrdAmt"] =  Convert.ToDecimal(this.txtCredit.Text);

	
			/// Save the row into the dataset 
			if (!this.oCustomer.SaveCustomer())
			{
				this.lblErrorMessage.Text = oCustomer.cErrormsg;
			}
			else
				// *** Reload the customer list
				this.LoadCustomerList();
		}


		protected string GetIdFromList() 
		{
			if (this.oCustomerList.SelectedItem == null) 
			{
				this.lblErrorMessage.Text = oCustomer.cErrormsg;
				return null;
			}	

			return this.oCustomerList.SelectedItem.Value;
		}

		public string ShowDS(DataSet loDS)
		{
			System.IO.StringWriter loStream = new System.IO.StringWriter();
			loDS.WriteXml(loStream);
			return loStream.ToString();

		}

		private void cmdAdd_Click(object sender, System.EventArgs e)
		{
			if (this.cmdAdd.Text == "New") 
			{
				this.cmdAdd.Text = "Add";
				this.txtCompany.Text = "";
				this.txtContact.Text = "";
				this.txtAddress.Text = "";
				this.txtCity.Text = "";
				this.txtState.Text = "";
				this.txtZip.Text = "";
				this.txtCountry.Text = "";
				this.txtPhone.Text = "";
				this.txtCredit.Text = "100.00";
				return;
			}
			
			if (!this.oCustomer.AddCustomer(this.txtCompany.Text,this.txtContact.Text,Convert.ToDecimal( this.txtCredit.Text)) )
			{
				this.lblErrorMessage.Text = this.oCustomer.cErrormsg;
				return;
			}

			// *** Reload the customer list
			this.LoadCustomerList();

			this.cmdAdd.Text = "New";
		}

		private void btnDelete_Click(object sender, System.EventArgs e)
		{
			string lcID = this.GetIdFromList();
			if (lcID == null || lcID == "") 
			{
				return;
			}

			if (!this.oCustomer.DeleteCustomer(lcID))
				this.lblErrorMessage.Text = this.oCustomer.cErrormsg;
			else 
			{
				this.lblErrorMessage.Text = "Customer Deleted...";

				// *** Reload the customer list
				this.LoadCustomerList();
			}
		}

		
	}
}
