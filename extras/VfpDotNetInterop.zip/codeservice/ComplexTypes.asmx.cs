
using System;
//using System.Collections;
//using System.ComponentModel;

using System.Data;
using System.Data.SqlClient;

//using System.Diagnostics;
using System.Web;
using System.Web.Services;

namespace CodeService
{
	/// <summary>
	/// Summary description for ComplexTypes.
	/// </summary>
	public class ComplexTypes 
	{
		/// Make sure you adjust the connection string as necessary
		public string cConnectString	=	"server=(local);database=pubs;uid=sa;pwd=;";

		/// these properties along with Open,Close,Load,Save really belong
		/// into a data wrapper or high level business object. For compactness'
		/// sake I've included them as part of the Web Service class.
		public SqlConnection oConn			=	null;
		public DataSet	oDS					=   null;
		public string cErrormsg				=   "";
		public bool lError					=   false;
		
		
		/// ***********************
		/// DATASET EXAMPLE METHODS
		/// ***********************

		/// <summary>
		/// Retrieve an authorlist that contains au_lname, au_fname,pk
		/// </summary>
		/// <param name="lcNameFilter">Last Name filter</param>
		/// <returns></returns>
		[WebMethod]
		public DataSet GetAuthorList(string lcNameFilter) 
		{

			if (lcNameFilter.Length == 0)
				lcNameFilter = "%";

			/// Open the connection to the database
			if ( !this.Open() )
				return null;

			int lnResult = this.Execute("select au_lname+ ', ' + au_fname AS name, pk " +
				"from authors where au_lname like '" + lcNameFilter + "%'" +
				" order by au_lname","Authors");

			if (this.lError) 
			{
				this.Close();
				return null;
			}

			return this.oDS;
		}

		/// <summary>
		/// Retrieve an authorlist that contains au_lname, au_fname,pk
		/// </summary>
		/// <param name="lcNameFilter">Last Name filter</param>
		/// <returns></returns>
		[WebMethod]
		public DataSet GetAuthors(string lcNameFilter) 
		{

			if (lcNameFilter.Length == 0)
				lcNameFilter = "%";

			/// Open the connection to the database
			if ( !this.Open() )
				return null;

			int lnResult = this.Execute("select * from authors where au_lname like '" + lcNameFilter + "%'" +
				" order by au_lname","Authors");

			if (this.lError) 
			{
				this.Close();
				return null;
			}

			return this.oDS;
		}


		[WebMethod]
		public DataSet GetAuthor(int lnPK)
		{
			/// Open the connection to the database
			if ( !this.Open() )
				return null;

			int lnResult = this.Execute("select * from authors where pk=" + lnPK.ToString(),"Author");

			this.Close();

			if (this.lError) 
			{
				return null;
			}

			return this.oDS;
		}

		[WebMethod]
		public bool SaveAuthor(DataSet loClientDS)
		{
			if (!this.Open())	
				return true;

			/// Even though we won't execute this command the data adapter needs this 
			/// command to figure out the key field info in order to properly do updates
			SqlDataAdapter oDSCommand = new SqlDataAdapter("select * from authors",this.oConn);


			/// This builds the Update/InsertCommands for the data adapter
			SqlCommandBuilder oCmdBuilder = new SqlCommandBuilder(oDSCommand);

			int lnRows = 0;
			try 
			{
				/// Take the changes in the dataset and sync to the database
				lnRows = oDSCommand.Update(loClientDS,"Author");
			}
			catch(Exception e)
			{
				return false;
			}

			if ( lnRows < 1 )
				return false;

			return true;
		}

		[WebMethod]
		public bool SaveAuthors(DataSet loClientDS)
		{
			if (!this.Open())	
				return true;

			/// Even though we won't execute this command the data adapter needs this 
			/// command to figure out the key field info in order to properly do updates
			SqlDataAdapter oDSCommand = new SqlDataAdapter("select * from authors",this.oConn);

			/// This builds the Update/InsertCommands for the data adapter
			SqlCommandBuilder oCmdBuilder = new SqlCommandBuilder(oDSCommand);

			int lnRows = 0;
			try 
			{
				/// Take the changes in the dataset and sync to the database
				lnRows = oDSCommand.Update(loClientDS,"Authors");
			}
			catch(Exception e)
			{
				return false;
			}

			if ( lnRows < 1 )
				return false;

			return true;
		}


		
		/// *********************
		/// DATA UTILITY ROUTINES	
		/// *********************
		/// these are not exposed throught the Web Service
		/// and really belong into an external class.	


		/// <summary>
		/// Sets up the connection for a query
		/// </summary>
		/// <returns></returns>
		protected bool Open()
		{
			/// create if it doesn't exist already
			if (this.oConn == null) 
			{
				try 
				{
					this.oConn = new SqlConnection(this.cConnectString);
				}
				catch(Exception e)
				{
					this.SetError( e.Message );
					return false;
				}
			}

			/// check if connection is open - if not open it
			if (this.oConn.State != ConnectionState.Open) 
			{
				try 
				{
					oConn.Open();
				}
				catch(Exception e)
				{
					this.SetError( e.Message );
					return false;
				}
			}

			/// make sure our dataset object exists
			if (oDS == null) 
				oDS = new DataSet();

			return true;
		}

		protected bool Close() 
		{
			if (oConn.State == ConnectionState.Open)
				try 
				{
					oConn.Close();
				}
				catch(Exception e)
				{
					this.SetError( e.Message );
					return false;
				}

			return true;
		}

		/// <summary>
		///  Executes a Select statement that returns a cursor.
		/// </summary>
		/// <param name="lcSQL"></param>
		/// <param name="lcCursor"></param>
		/// <returns></returns>
		protected int Execute(string lcSQL, string lcCursor)
		{
			if (!this.Open()) 
				return 0;

			SqlDataAdapter oDSCommand = new SqlDataAdapter();
			oDSCommand.SelectCommand = 
				new SqlCommand(lcSQL,oConn);


			/// remove the table if it exists - fail and ignore
			try 
			{
				oDS.Tables.Remove(lcCursor);
			}
			catch(Exception e) { }  // Ignore the error
	
			try 
			{
				oDSCommand.Fill(oDS,lcCursor);
			}
			catch(Exception e)
			{
				this.SetError(e.Message);
				return 0;
			}

			return oDS.Tables[lcCursor].Rows.Count;
		}

		
		protected void SetError(string lcErrormsg)
		{
			if (lcErrormsg.Length == 0) 
			{
				cErrormsg = "";
				lError = false;
				return;
			}

			cErrormsg = lcErrormsg;
			lError = true;
		}



	}

}
