vti_encoding:SR|utf8-nl
vti_timelastmodified:TR|06 Jun 2001 06:17:50 -0000
vti_extenderversion:SR|5.0.2.3311
vti_lineageid:SR|{56C3D1CD-881B-4E44-902E-C8A553B0227D}
vti_cacheddtm:TX|06 Jun 2001 06:17:50 -0000
vti_filesize:IR|1915
vti_backlinkinfo:VX|
