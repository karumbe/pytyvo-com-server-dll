namespace CodeService
{
    using System;
	using System.IO;
    using System.Collections;
    using System.ComponentModel;
    using System.Data;
	using System.Data.OleDb;
    using System.Diagnostics;
    using System.Web;
    using System.Web.Services;

	using BusObjects;

    /// <summary>
    ///    Summary description for CodeWebService.
    /// </summary>
    public class CodeWebService : System.Web.Services.WebService
	{
		protected string cAuthorConnectionString = "server=(local);provider=SQLOleDb;database=pubs;uid=sa;pwd=wwind";
		
		public CodeWebService()
        {
            //CODEGEN: This call is required by the ASP.NET Web Services Designer
            InitializeComponent();
        }

		#region Component Designer generated code
        /// <summary>
        ///    Required method for Designer support - do not modify
        ///    the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
        }
		#endregion

		[WebMethod]
		public string HelloWorld(string lcName)
		{
			lcName = lcName + "!";
			return "Hello mad, mad World... " + lcName ;
		}

		[WebMethod]
		public DateTime GetServerTime() 
		{
			return DateTime.Now;
		}

		[WebMethod]
		public string WhoAmI() 
		{
			return User.Identity.Name;
		}
		[WebMethod]
		public decimal AddNumbers(decimal lnNumber1, decimal lnNumber2) 
		{
			return lnNumber1 + lnNumber2;	
		}

		[WebMethod]
		public System.Data.DataSet GetAuthorData(string lcID)
		{

			if (lcID == "" )
				lcID = "%";

			DataSet ds = new DataSet();

			string cConnection = this.cAuthorConnectionString;

			OleDbConnection	oConn = new OleDbConnection(cConnection);
			
			OleDbDataAdapter oAdapter = new OleDbDataAdapter();
			oAdapter.SelectCommand = 
				new OleDbCommand("select * from Authors where au_id like '" + lcID + "%'",oConn);
	            
			try 
			{
				oConn.Open();
			}
			catch(Exception e) 
			{
				return null;
			}

			oAdapter.Fill(ds,"Authors");

			
			oConn.Close();

			return ds;
			
		}

		[WebMethod]
		public string GetAuthorDataString(string lcID)
		{

			if (lcID == "" )
				lcID = "%";

			DataSet ds = new DataSet();

			string cConnection = this.cAuthorConnectionString;

			OleDbConnection	oConn = new OleDbConnection(cConnection);
			
			OleDbDataAdapter oAdapter = new OleDbDataAdapter();
			oAdapter.SelectCommand = 
				new OleDbCommand("select * from Authors where au_id like '" + lcID + "%'",oConn);
	            
			try 
			{
				oConn.Open();
			}
			catch(Exception e) 
			{
				return null;
			}

			oAdapter.Fill(ds,"Authors");

			
			oConn.Close();

			return ds.WriteXml(
			
		}

		[WebMethod]
		public System.Data.DataSet GetAuthorAndEmployeeData(string lcID)
		{

			if (lcID == "" )
				lcID = "%";

			DataSet ds = new DataSet();

			string cConnection = this.cAuthorConnectionString;
			OleDbConnection	oConn = new OleDbConnection(cConnection);
			
			OleDbDataAdapter oAdapter = new OleDbDataAdapter();
			oAdapter.SelectCommand = 
				new OleDbCommand("select * from Authors where au_id like '" + lcID + "%'",oConn);
	            
			try 
			{
				oConn.Open();
			}
			catch(Exception e) 
			{
				return null;
			}

			oAdapter.Fill(ds,"Authors");

			oAdapter.SelectCommand = 
				new OleDbCommand("select * from Employee",oConn);
			oAdapter.Fill(ds,"Employees");
			
			oConn.Close();

			return ds;
		}


		[WebMethod]
		public Customer GetCustomer(int lnPK) 
		{
			Customer oCustomer = new Customer();

			if (!oCustomer.Load(lnPK))
				return null;

			return oCustomer;
		}

		[WebMethod]
		public Customer GetCustomerByName(string lcName) 
		{
			Customer oCustomer = new Customer();

			if (!oCustomer.Load(lcName))
				return null;

			return oCustomer;
		}

		public string PassCustomer(Customer loCustomer) 
		{
			if (loCustomer != null)
			{
				return loCustomer.cCompany;
			}

			return "";
		}

		[WebMethod]
		public string ReturnXML(string lcName) 
		{
			return "<?xml version=\"1.0\"?>\r\n<data>" + lcName + "</data>";
		}

		[WebMethod]
		public string CrashMe()
		{
			Exception ex = new Exception("Invalid Connection String");
			throw(ex);
			return "";
		}	

		// *** Check different return types
		[WebMethod]
		public byte[] GetBinaryFile(string lcFile) 
		{
			byte[] lcResult = null;

			try 
			{
				FileStream loStream = new FileStream(lcFile,FileMode.Open);
				loStream.Read(lcResult,0,(int) loStream.Length);
				loStream.Close();
			}
			catch(Exception) 
			{
				return null;
			}
			return lcResult;
		}

		[WebMethod]
		public string[] GetStrings() 
		{
			string[] strings = new string[3];
			strings[1] = "Rick";
			strings[2] = "Strahl";
			strings[0] = "Test";

			return strings;
		}

		[WebMethod]
		public string ObjectParm(SimpleParm loParm) 
		{
			return loParm.cname;
		}

	}
		

	public class SimpleParm 
	{
		public int nvalue = 0;
		public string cname = "";
	}

}
