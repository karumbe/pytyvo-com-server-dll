namespace BusObjects
{
	using System;
	using System.Data;
	using System.Data.OleDb;

	/// <summary>
	///		Summary description for BusObjects.
	/// </summary>
	public class Customer
	{
		protected string cConnectString = "provider=SQLOleDb;server=(local);uid=sa;pwd=wwind;database=WestWindWebStore";

		public string cLastName = "";
		public string cFirstName = "";
		public string cCompany = "";

		public DateTime tEntered = DateTime.MinValue;
		
		public bool lError = false;
		public string cErrorMsg = "";

		public Address oAddress;
		
		
		public Customer()
		{
			//
			// TODO: Add Constructor Logic here
			//
			oAddress = new Address();
		}
		
		public bool Load(int lnPK) 
		{
			DataSet ds = new DataSet();
			OleDbConnection	oConn = 
				new OleDbConnection(this.cConnectString);
			
			OleDbDataAdapter oDSCommand = new OleDbDataAdapter();
			oDSCommand.SelectCommand = 
				new OleDbCommand("select * from wws_customers where pk = " + lnPK.ToString(),
				oConn);
	
			try 
			{
				oConn.Open();

				oDSCommand.Fill(ds,"wws_customers");
			}
			catch(Exception e)
			{
				lError = true;
				cErrorMsg = e.Message;
				return false;
			}

			if (ds.Tables["wws_customers"].Rows.Count < 1)
			{
				return false;
			}

			DataRow loRow = ds.Tables["wws_customers"].Rows[0];
			cLastName = loRow["lastname"].ToString();
			cFirstName = loRow["firstname"].ToString();
			cCompany = loRow["company"].ToString();
			tEntered = (DateTime) loRow["entered"];

			oAddress.cAddress = loRow["address"].ToString();
			oAddress.cPhone = loRow["phone"].ToString();
			oAddress.cEmail = loRow["email"].ToString();
			
			return true;
		}

		public bool Load(string lcName)
		{
			DataSet ds = new DataSet();
			OleDbConnection	oConn = 
				new OleDbConnection(this.cConnectString);
			
			OleDbDataAdapter oDSCommand = new OleDbDataAdapter();
			oDSCommand.SelectCommand = 
				new OleDbCommand("select * from wws_customers where lastname like '" + lcName.Trim() + "'",
				oConn);
	
			try
			{
				oConn.Open();

				oDSCommand.Fill(ds,"wws_customers");
			}
			catch(Exception e)
			{
				lError = true;
				cErrorMsg = e.Message;
				return false;
			}

			if (ds.Tables["wws_customers"].Rows.Count < 1)
			{
				return false;
			}

			DataRow loRow = ds.Tables["wws_customers"].Rows[0];
			cLastName = loRow["lastname"].ToString();
			cFirstName = loRow["firstname"].ToString();
			cCompany = loRow["company"].ToString();
			tEntered = (DateTime) loRow["entered"];

			oAddress.cAddress = loRow["address"].ToString();
			oAddress.cPhone = loRow["phone"].ToString();
			oAddress.cEmail = loRow["email"].ToString();
			
			return true;
			
		}

	}

	public class Address
	{
		public string cAddress = "";
		public string cPhone = "";
		public string cEmail = "";

		public Address()
		{

		}

	}
}
