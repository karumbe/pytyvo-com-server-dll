
CREATE TABLE [dbo].[wws_customers] (
	[pk] [int] NOT NULL ,
	[storepk] [int] NOT NULL ,
	[userid] [char] (9) NOT NULL ,
	[lastname] [char] (30) NOT NULL ,
	[firstname] [char] (20) NOT NULL ,
	[company] [char] (40) NOT NULL ,
	[address] [text] NOT NULL ,
	[city] [char] (20) NOT NULL ,
	[state] [char] (2) NOT NULL ,
	[zip] [char] (12) NOT NULL ,
	[zip4] [char] (4) NOT NULL ,
	[country] [char] (30) NOT NULL ,
	[countryid] [char] (2) NOT NULL ,
	[phone] [text] NOT NULL ,
	[email] [varchar] (50) NOT NULL ,
	[fax] [text] NOT NULL ,
	[notes] [text] NOT NULL ,
	[shipping] [text] NOT NULL ,
	[entered] [datetime] NOT NULL ,
	[updated] [datetime] NOT NULL ,
	[lastorder] [datetime] NOT NULL ,
	[referral] [text] NOT NULL ,
	[password] [char] (10) NOT NULL ,
	[source] [text] NOT NULL ,
	[downloaded] [bit] NOT NULL ,
	[xml] [text] NOT NULL ,
	[custtype] [numeric](1, 0) NOT NULL ,
	[billrate] [int] NOT NULL 
) ON [PRIMARY] TEXTIMAGE_ON [PRIMARY]
GO


INSERT wws_customers (ADDRESS,BILLRATE,CITY,COMPANY,COUNTRY,COUNTRYID,CUSTTYPE,DOWNLOADED,EMAIL,ENTERED,FAX,FIRSTNAME,LASTNAME,LASTORDER,NOTES,PASSWORD,PHONE,PK,REFERRAL,SHIPPING,SOURCE,STATE,STOREPK,UPDATED,USERID,XML,ZIP,ZIP4) VALUES ('',200,'                    ','Anthology, Inc.                         ','                              ','US',2,0,'randyp@cycla.com','10/05/1999','','Keri                ','Sabatini                      ','','','          ','',2,'','','','  ',0,'08/02/2001','_S8Z0D5NY','','            ','    ')
INSERT wws_customers (ADDRESS,BILLRATE,CITY,COMPANY,COUNTRY,COUNTRYID,CUSTTYPE,DOWNLOADED,EMAIL,ENTERED,FAX,FIRSTNAME,LASTNAME,LASTORDER,NOTES,PASSWORD,PHONE,PK,REFERRAL,SHIPPING,SOURCE,STATE,STOREPK,UPDATED,USERID,XML,ZIP,ZIP4) VALUES ('4090 Wembley Forest Way',150,'Doraville           ','Stevenson & Associates V                ','United States                 ','US',2,0,'dsharpie@mindspring.com','10/05/1999','','David               ','Stevenson                     ','','','sharper   ','404-690-6123',3,'','','WCGIVEAWAY_01012000
','GA',0,'08/02/2001','_S8Z17D2C','','30340       ','    ')
INSERT wws_customers (ADDRESS,BILLRATE,CITY,COMPANY,COUNTRY,COUNTRYID,CUSTTYPE,DOWNLOADED,EMAIL,ENTERED,FAX,FIRSTNAME,LASTNAME,LASTORDER,NOTES,PASSWORD,PHONE,PK,REFERRAL,SHIPPING,SOURCE,STATE,STOREPK,UPDATED,USERID,XML,ZIP,ZIP4) VALUES ('',0,'                    ','OTS Group                               ','                              ','US',0,0,'hoskam@horizon.nl, mathon_hoskam@otsgroup.nl','10/06/1999','','M.                  ','Hoskam                        ','','','          ','',4,'','','','  ',0,'08/02/2001','_S9007JET','','            ','    ')
INSERT wws_customers (ADDRESS,BILLRATE,CITY,COMPANY,COUNTRY,COUNTRYID,CUSTTYPE,DOWNLOADED,EMAIL,ENTERED,FAX,FIRSTNAME,LASTNAME,LASTORDER,NOTES,PASSWORD,PHONE,PK,REFERRAL,SHIPPING,SOURCE,STATE,STOREPK,UPDATED,USERID,XML,ZIP,ZIP4) VALUES ('123 Anywhere lane
Anywhere, USA',0,'                    ','Pardoe Development Corporation          ','                              ','US',0,0,'info@pardoeonline.com','10/06/1999','','Pardoe Jr.          ','Guy                           ','','','          ','(133) 123-1231',5,'','','','  ',0,'08/02/2001','_S9009WKE','','            ','    ')
INSERT wws_customers (ADDRESS,BILLRATE,CITY,COMPANY,COUNTRY,COUNTRYID,CUSTTYPE,DOWNLOADED,EMAIL,ENTERED,FAX,FIRSTNAME,LASTNAME,LASTORDER,NOTES,PASSWORD,PHONE,PK,REFERRAL,SHIPPING,SOURCE,STATE,STOREPK,UPDATED,USERID,XML,ZIP,ZIP4) VALUES ('',0,'                    ','JTK-Data Oy                             ','                              ','US',0,0,'kari.sinivuori@icon.fi','10/06/1999','','Sinivuori           ','Kari                          ','','','          ','',6,'','','','  ',0,'08/02/2001','_S900A54D','','            ','    ')
INSERT wws_customers (ADDRESS,BILLRATE,CITY,COMPANY,COUNTRY,COUNTRYID,CUSTTYPE,DOWNLOADED,EMAIL,ENTERED,FAX,FIRSTNAME,LASTNAME,LASTORDER,NOTES,PASSWORD,PHONE,PK,REFERRAL,SHIPPING,SOURCE,STATE,STOREPK,UPDATED,USERID,XML,ZIP,ZIP4) VALUES ('234 Toddler Road',150,'Boston              ','USDatacenters.com                       ','United States                 ','US',2,0,'hchattaway@usdatacenters.com','10/06/1999','','Harold              ','Chattaway SR.                 ','','','harold    ','(123) 123-1231',7,'','','','MA',0,'08/02/2001','_S900B5C4','','89213       ','    ')
INSERT wws_customers (ADDRESS,BILLRATE,CITY,COMPANY,COUNTRY,COUNTRYID,CUSTTYPE,DOWNLOADED,EMAIL,ENTERED,FAX,FIRSTNAME,LASTNAME,LASTORDER,NOTES,PASSWORD,PHONE,PK,REFERRAL,SHIPPING,SOURCE,STATE,STOREPK,UPDATED,USERID,XML,ZIP,ZIP4) VALUES ('',185,'                    ','Platinum Software                       ','                              ','US',2,0,'mparsons@platsoft.com','10/06/1999','','Michael             ','Parsons                       ','','','          ','',8,'','','','  ',0,'08/02/2001','_S900DFB2','','            ','    ')
INSERT wws_customers (ADDRESS,BILLRATE,CITY,COMPANY,COUNTRY,COUNTRYID,CUSTTYPE,DOWNLOADED,EMAIL,ENTERED,FAX,FIRSTNAME,LASTNAME,LASTORDER,NOTES,PASSWORD,PHONE,PK,REFERRAL,SHIPPING,SOURCE,STATE,STOREPK,UPDATED,USERID,XML,ZIP,ZIP4) VALUES ('123 Anyroad 
Hawaii',190,'                    ','American Tech, Incorporated             ','Afghanistan                   ','US',2,0,'randyc@netlabs.net','10/06/1999','','Randy               ','Clark                         ','','','          ','',9,'','','','  ',0,'08/02/2001','_S900EKF5','','            ','    ')
INSERT wws_customers (ADDRESS,BILLRATE,CITY,COMPANY,COUNTRY,COUNTRYID,CUSTTYPE,DOWNLOADED,EMAIL,ENTERED,FAX,FIRSTNAME,LASTNAME,LASTORDER,NOTES,PASSWORD,PHONE,PK,REFERRAL,SHIPPING,SOURCE,STATE,STOREPK,UPDATED,USERID,XML,ZIP,ZIP4) VALUES ('2551 Riva Road
MS 5-389',0,'Annapolis           ','ARINC Incorporated                      ','United States                 ','US',0,0,'dfolk@arinc.com','10/06/1999','','Doe                 ','Jane                          ','','','tddrdf    ','(410)266-4863',10,'','','WCGIVEAWAY_01012000
','MD',0,'08/02/2001','_S900GTV0','','21401       ','    ')
INSERT wws_customers (ADDRESS,BILLRATE,CITY,COMPANY,COUNTRY,COUNTRYID,CUSTTYPE,DOWNLOADED,EMAIL,ENTERED,FAX,FIRSTNAME,LASTNAME,LASTORDER,NOTES,PASSWORD,PHONE,PK,REFERRAL,SHIPPING,SOURCE,STATE,STOREPK,UPDATED,USERID,XML,ZIP,ZIP4) VALUES ('',0,'                    ','ElseWare                                ','                              ','US',0,0,'dleopold@compuserve.com','10/06/1999','','Dale                ','Leopold                       ','','','          ','',11,'','','','  ',0,'08/02/2001','_S900HVWK','','            ','    ')
INSERT wws_customers (ADDRESS,BILLRATE,CITY,COMPANY,COUNTRY,COUNTRYID,CUSTTYPE,DOWNLOADED,EMAIL,ENTERED,FAX,FIRSTNAME,LASTNAME,LASTORDER,NOTES,PASSWORD,PHONE,PK,REFERRAL,SHIPPING,SOURCE,STATE,STOREPK,UPDATED,USERID,XML,ZIP,ZIP4) VALUES ('2403 N Nettleton Street',155,'Spokane             ','Computer Consulting Inmc                ','United States                 ','US',2,0,'tvoss@computer-consulting.com','10/06/1999','','Terry               ','Voss                          ','','','compcons  ','5093277202',12,'West Wind Technologies Web Site','','','WA',0,'08/02/2001','_S900LB8I','','99205       ','    ')
INSERT wws_customers (ADDRESS,BILLRATE,CITY,COMPANY,COUNTRY,COUNTRYID,CUSTTYPE,DOWNLOADED,EMAIL,ENTERED,FAX,FIRSTNAME,LASTNAME,LASTORDER,NOTES,PASSWORD,PHONE,PK,REFERRAL,SHIPPING,SOURCE,STATE,STOREPK,UPDATED,USERID,XML,ZIP,ZIP4) VALUES ('',0,'                    ','INFOLynx                                ','                              ','US',0,0,'jpowers@infolynxeft.com','10/06/1999','','John                ','Powers                        ','','','          ','',13,'','','','  ',0,'08/02/2001','_S900LBE7','','            ','    ')
INSERT wws_customers (ADDRESS,BILLRATE,CITY,COMPANY,COUNTRY,COUNTRYID,CUSTTYPE,DOWNLOADED,EMAIL,ENTERED,FAX,FIRSTNAME,LASTNAME,LASTORDER,NOTES,PASSWORD,PHONE,PK,REFERRAL,SHIPPING,SOURCE,STATE,STOREPK,UPDATED,USERID,XML,ZIP,ZIP4) VALUES ('2514 Florida Ave',0,'Richmond            ','Palecek, Inc.                           ','United States                 ','US',0,0,'warrenc@palecek.com','10/06/1999','','Warren              ','Coykendall                    ','','','palecek   ','510-236-7730',14,'','','','CA',0,'08/02/2001','_S900PVXW','','94804       ','    ')
INSERT wws_customers (ADDRESS,BILLRATE,CITY,COMPANY,COUNTRY,COUNTRYID,CUSTTYPE,DOWNLOADED,EMAIL,ENTERED,FAX,FIRSTNAME,LASTNAME,LASTORDER,NOTES,PASSWORD,PHONE,PK,REFERRAL,SHIPPING,SOURCE,STATE,STOREPK,UPDATED,USERID,XML,ZIP,ZIP4) VALUES ('',0,'                    ','MRM Technical Group                     ','                              ','US',0,0,'rgonring@mrmnetwork.com','10/06/1999','','Russ                ','Gonring                       ','','','          ','',15,'','','','  ',0,'08/02/2001','_S900RLSN','','            ','    ')
INSERT wws_customers (ADDRESS,BILLRATE,CITY,COMPANY,COUNTRY,COUNTRYID,CUSTTYPE,DOWNLOADED,EMAIL,ENTERED,FAX,FIRSTNAME,LASTNAME,LASTORDER,NOTES,PASSWORD,PHONE,PK,REFERRAL,SHIPPING,SOURCE,STATE,STOREPK,UPDATED,USERID,XML,ZIP,ZIP4) VALUES ('',190,'                    ','Anthology, Inc.                         ','                              ','US',2,0,'keri@anthology.com','10/06/1999','','Keri                ','Sabatini                      ','','','          ','',16,'','','','  ',0,'08/02/2001','_S900S6OY','','            ','    ')
INSERT wws_customers (ADDRESS,BILLRATE,CITY,COMPANY,COUNTRY,COUNTRYID,CUSTTYPE,DOWNLOADED,EMAIL,ENTERED,FAX,FIRSTNAME,LASTNAME,LASTORDER,NOTES,PASSWORD,PHONE,PK,REFERRAL,SHIPPING,SOURCE,STATE,STOREPK,UPDATED,USERID,XML,ZIP,ZIP4) VALUES ('32 Kaiea Place',0,'Paia                ','West Wind Technologies                  ','United States                 ','US',0,0,'rstrahl@west-wind.com','10/01/2000','','Rick                ','Strahl                        ','','','wwind     ','(808) 579-8342',1,'Microsoft Link or Referral','','','HI',0,'08/02/2001','01E0NNOPF','','96779       ','    ')
INSERT wws_customers (ADDRESS,BILLRATE,CITY,COMPANY,COUNTRY,COUNTRYID,CUSTTYPE,DOWNLOADED,EMAIL,ENTERED,FAX,FIRSTNAME,LASTNAME,LASTORDER,NOTES,PASSWORD,PHONE,PK,REFERRAL,SHIPPING,SOURCE,STATE,STOREPK,UPDATED,USERID,XML,ZIP,ZIP4) VALUES ('32 Kaiea Place',0,'Paia                ','West Wind                               ','United States                 ','US',0,0,'john@west-wind.com','07/29/2001','','John                ','Doe                           ','','','john      ','808 579-8342',824350,'','','','HI',0,'08/02/2001','0G1103L2O','','96779       ','    ')
