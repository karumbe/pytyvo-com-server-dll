using System;
using System.Drawing;
using System.Collections;
using System.ComponentModel;
using System.Windows.Forms;

using CodeClient.CodeWebService;
using CodeClient.TypeWebService;

namespace CodeClient
{
	/// <summary>
	/// Summary description for StartupMenu.
	/// </summary>
	public class StartupMenu : System.Windows.Forms.Form
	{
		private System.Windows.Forms.Button button1;
		private System.Windows.Forms.Button button2;
		private System.Windows.Forms.Button button3;
		/// <summary>
		/// Required designer variable.
		/// </summary>
		private System.ComponentModel.Container components = null;

		public StartupMenu()
		{
			//
			// Required for Windows Form Designer support
			//
			InitializeComponent();

			//
			// TODO: Add any constructor code after InitializeComponent call
			//
		}

		/// <summary>
		/// Clean up any resources being used.
		/// </summary>
		protected override void Dispose( bool disposing )
		{
			if( disposing )
			{
				if(components != null)
				{
					components.Dispose();
				}
			}
			base.Dispose( disposing );
		}

		#region Windows Form Designer generated code
		/// <summary>
		/// Required method for Designer support - do not modify
		/// the contents of this method with the code editor.
		/// </summary>
		private void InitializeComponent()
		{
			this.button1 = new System.Windows.Forms.Button();
			this.button2 = new System.Windows.Forms.Button();
			this.button3 = new System.Windows.Forms.Button();
			this.SuspendLayout();
			// 
			// button1
			// 
			this.button1.Font = new System.Drawing.Font("Tahoma", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((System.Byte)(0)));
			this.button1.Location = new System.Drawing.Point(17, 16);
			this.button1.Name = "button1";
			this.button1.Size = new System.Drawing.Size(189, 33);
			this.button1.TabIndex = 0;
			this.button1.Text = "First Web Service Demo";
			this.button1.Click += new System.EventHandler(this.button1_Click);
			// 
			// button2
			// 
			this.button2.Font = new System.Drawing.Font("Tahoma", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((System.Byte)(0)));
			this.button2.Location = new System.Drawing.Point(17, 53);
			this.button2.Name = "button2";
			this.button2.Size = new System.Drawing.Size(189, 33);
			this.button2.TabIndex = 0;
			this.button2.Text = "Connected Author Web Service";
			this.button2.Click += new System.EventHandler(this.button2_Click);
			// 
			// button3
			// 
			this.button3.Font = new System.Drawing.Font("Tahoma", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((System.Byte)(0)));
			this.button3.Location = new System.Drawing.Point(17, 92);
			this.button3.Name = "button3";
			this.button3.Size = new System.Drawing.Size(189, 33);
			this.button3.TabIndex = 0;
			this.button3.Text = "Disconnected Author Web Service";
			this.button3.Click += new System.EventHandler(this.button3_Click);
			// 
			// StartupMenu
			// 
			this.AutoScaleBaseSize = new System.Drawing.Size(5, 14);
			this.ClientSize = new System.Drawing.Size(227, 150);
			this.Controls.AddRange(new System.Windows.Forms.Control[] {
																		  this.button3,
																		  this.button2,
																		  this.button1});
			this.Font = new System.Drawing.Font("Tahoma", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((System.Byte)(0)));
			this.Name = "StartupMenu";
			this.SizeGripStyle = System.Windows.Forms.SizeGripStyle.Hide;
			this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
			this.Text = "Web Service Client Demos";
			this.Load += new System.EventHandler(this.StartupMenu_Load);
			this.ResumeLayout(false);

		}
		#endregion

		private void StartupMenu_Load(object sender, System.EventArgs e)
		{

		}

		public static void Main(string[] args) 
		{
			Application.Run( new StartupMenu() );
		}

		private void button1_Click(object sender, System.EventArgs e)
		{
			WebDemoClient.WebDemoClient oWDC = new WebDemoClient.WebDemoClient();
			oWDC.Show();
			
		}

		private void button2_Click(object sender, System.EventArgs e)
		{
			CodeClient.AuthorForm oAF = new AuthorForm();
			oAF.Show();
		}

		private void button3_Click(object sender, System.EventArgs e)
		{
			CodeClient.AuthorFormOffline oAFO = new AuthorFormOffline();
			oAFO.Show();
		}

	}
}
