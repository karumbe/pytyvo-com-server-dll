namespace WebDemoClient
{
	using System;
	using System.Drawing;
	using System.Collections;
	using System.ComponentModel;
	using System.Windows.Forms;
	
	using System.Data;
	using System.Data.OleDb;

	using CodeClient.CodeWebService	;

	/// <summary>
	///		Summary description for WebDemoClient.
	/// </summary>
	public class WebDemoClient : System.Windows.Forms.Form
	{
		/// <summary>
		///		Required designer variable.
		/// </summary>
		private System.ComponentModel.Container components;
		private System.Windows.Forms.Label label1;
		//private System.Windows.Forms.Button button1;
		private System.Windows.Forms.TextBox txtServerTime;
		private System.Windows.Forms.Button cmdGetServerTime;
		private System.Windows.Forms.ListBox oAuthorList;
		private System.Windows.Forms.Button cmdGetAuthors;
		private System.Windows.Forms.TextBox txtAddress;
		private System.Windows.Forms.TextBox txtName;
		private System.Windows.Forms.TextBox txtPhone;
		private System.Windows.Forms.GroupBox groupBox1;
		private System.Windows.Forms.GroupBox groupBox2;
		private System.Windows.Forms.Label label2;
		private System.Windows.Forms.Label label3;
		private System.Windows.Forms.TextBox txtSearchCustomer;
		private System.Windows.Forms.Button cmdGetCustomer;
		private System.Windows.Forms.TextBox txtCustName;
		private System.Windows.Forms.TextBox txtCustAddress;
		private System.Windows.Forms.TextBox txtCustEmail;
		private System.Windows.Forms.TextBox txtCustPhone;
		private System.Windows.Forms.Label label4;
		private System.Windows.Forms.Label label5;
		private System.Windows.Forms.Label label6;
		private System.Windows.Forms.Label label7;
		private System.Windows.Forms.GroupBox groupBox3;

		public DataSet ds;
		

		#region Windows Form Designer generated code
		/// <summary>
		///		Required method for Designer support - do not modify
		///		the contents of this method with the code editor.
		/// </summary>
		private void InitializeComponent()
		{
			this.txtCustEmail = new System.Windows.Forms.TextBox();
			this.cmdGetAuthors = new System.Windows.Forms.Button();
			this.label5 = new System.Windows.Forms.Label();
			this.label6 = new System.Windows.Forms.Label();
			this.label7 = new System.Windows.Forms.Label();
			this.label1 = new System.Windows.Forms.Label();
			this.label2 = new System.Windows.Forms.Label();
			this.label3 = new System.Windows.Forms.Label();
			this.txtCustAddress = new System.Windows.Forms.TextBox();
			this.txtCustName = new System.Windows.Forms.TextBox();
			this.groupBox2 = new System.Windows.Forms.GroupBox();
			this.groupBox3 = new System.Windows.Forms.GroupBox();
			this.txtAddress = new System.Windows.Forms.TextBox();
			this.txtCustPhone = new System.Windows.Forms.TextBox();
			this.txtName = new System.Windows.Forms.TextBox();
			this.txtServerTime = new System.Windows.Forms.TextBox();
			this.label4 = new System.Windows.Forms.Label();
			this.txtSearchCustomer = new System.Windows.Forms.TextBox();
			this.cmdGetCustomer = new System.Windows.Forms.Button();
			this.groupBox1 = new System.Windows.Forms.GroupBox();
			this.oAuthorList = new System.Windows.Forms.ListBox();
			this.txtPhone = new System.Windows.Forms.TextBox();
			this.cmdGetServerTime = new System.Windows.Forms.Button();
			this.groupBox2.SuspendLayout();
			this.SuspendLayout();
			// 
			// txtCustEmail
			// 
			this.txtCustEmail.Location = new System.Drawing.Point(88, 512);
			this.txtCustEmail.Name = "txtCustEmail";
			this.txtCustEmail.Size = new System.Drawing.Size(216, 20);
			this.txtCustEmail.TabIndex = 11;
			this.txtCustEmail.Text = "";
			// 
			// cmdGetAuthors
			// 
			this.cmdGetAuthors.Location = new System.Drawing.Point(16, 288);
			this.cmdGetAuthors.Name = "cmdGetAuthors";
			this.cmdGetAuthors.Size = new System.Drawing.Size(152, 24);
			this.cmdGetAuthors.TabIndex = 2;
			this.cmdGetAuthors.Text = "Get Authors";
			this.cmdGetAuthors.Click += new System.EventHandler(this.cmdGetAuthors_Click);
			// 
			// label5
			// 
			this.label5.Location = new System.Drawing.Point(32, 440);
			this.label5.Name = "label5";
			this.label5.Size = new System.Drawing.Size(48, 16);
			this.label5.TabIndex = 12;
			this.label5.Text = "Address:";
			// 
			// label6
			// 
			this.label6.Location = new System.Drawing.Point(32, 488);
			this.label6.Name = "label6";
			this.label6.Size = new System.Drawing.Size(48, 16);
			this.label6.TabIndex = 12;
			this.label6.Text = "Phone:";
			// 
			// label7
			// 
			this.label7.Location = new System.Drawing.Point(32, 512);
			this.label7.Name = "label7";
			this.label7.Size = new System.Drawing.Size(48, 16);
			this.label7.TabIndex = 12;
			this.label7.Text = "Email:";
			// 
			// label1
			// 
			this.label1.BackColor = System.Drawing.Color.Transparent;
			this.label1.Location = new System.Drawing.Point(16, 32);
			this.label1.Name = "label1";
			this.label1.Size = new System.Drawing.Size(72, 16);
			this.label1.TabIndex = 1;
			this.label1.Text = "Server Time:";
			// 
			// label2
			// 
			this.label2.BackColor = System.Drawing.Color.Transparent;
			this.label2.Location = new System.Drawing.Point(175, 32);
			this.label2.Name = "label2";
			this.label2.Size = new System.Drawing.Size(114, 26);
			this.label2.TabIndex = 1;
			this.label2.Text = "Customer Detail:";
			// 
			// label3
			// 
			this.label3.BackColor = System.Drawing.Color.Transparent;
			this.label3.Location = new System.Drawing.Point(32, 352);
			this.label3.Name = "label3";
			this.label3.Size = new System.Drawing.Size(114, 16);
			this.label3.TabIndex = 1;
			this.label3.Text = "Search for Customer:";
			// 
			// txtCustAddress
			// 
			this.txtCustAddress.Location = new System.Drawing.Point(88, 432);
			this.txtCustAddress.Multiline = true;
			this.txtCustAddress.Name = "txtCustAddress";
			this.txtCustAddress.Size = new System.Drawing.Size(216, 56);
			this.txtCustAddress.TabIndex = 9;
			this.txtCustAddress.Text = "";
			// 
			// txtCustName
			// 
			this.txtCustName.Location = new System.Drawing.Point(88, 408);
			this.txtCustName.Name = "txtCustName";
			this.txtCustName.Size = new System.Drawing.Size(216, 20);
			this.txtCustName.TabIndex = 8;
			this.txtCustName.Text = "";
			// 
			// groupBox2
			// 
			this.groupBox2.Controls.AddRange(new System.Windows.Forms.Control[] {
																					this.label2});
			this.groupBox2.Location = new System.Drawing.Point(8, 88);
			this.groupBox2.Name = "groupBox2";
			this.groupBox2.Size = new System.Drawing.Size(352, 232);
			this.groupBox2.TabIndex = 6;
			this.groupBox2.TabStop = false;
			this.groupBox2.Text = " Author Data Set Demo  ";
			// 
			// groupBox3
			// 
			this.groupBox3.Location = new System.Drawing.Point(8, 336);
			this.groupBox3.Name = "groupBox3";
			this.groupBox3.Size = new System.Drawing.Size(352, 208);
			this.groupBox3.TabIndex = 6;
			this.groupBox3.TabStop = false;
			this.groupBox3.Text = "Customer Object Demo ";
			// 
			// txtAddress
			// 
			this.txtAddress.Location = new System.Drawing.Point(182, 168);
			this.txtAddress.Multiline = true;
			this.txtAddress.Name = "txtAddress";
			this.txtAddress.Size = new System.Drawing.Size(168, 88);
			this.txtAddress.TabIndex = 5;
			this.txtAddress.Text = "";
			// 
			// txtCustPhone
			// 
			this.txtCustPhone.Location = new System.Drawing.Point(88, 488);
			this.txtCustPhone.Name = "txtCustPhone";
			this.txtCustPhone.Size = new System.Drawing.Size(216, 20);
			this.txtCustPhone.TabIndex = 10;
			this.txtCustPhone.Text = "";
			// 
			// txtName
			// 
			this.txtName.Location = new System.Drawing.Point(182, 136);
			this.txtName.Name = "txtName";
			this.txtName.Size = new System.Drawing.Size(168, 20);
			this.txtName.TabIndex = 4;
			this.txtName.Text = "";
			// 
			// txtServerTime
			// 
			this.txtServerTime.Location = new System.Drawing.Point(96, 32);
			this.txtServerTime.Name = "txtServerTime";
			this.txtServerTime.Size = new System.Drawing.Size(152, 20);
			this.txtServerTime.TabIndex = 0;
			this.txtServerTime.Text = "";
			// 
			// label4
			// 
			this.label4.Location = new System.Drawing.Point(32, 416);
			this.label4.Name = "label4";
			this.label4.Size = new System.Drawing.Size(48, 16);
			this.label4.TabIndex = 12;
			this.label4.Text = "Name:";
			// 
			// txtSearchCustomer
			// 
			this.txtSearchCustomer.Location = new System.Drawing.Point(32, 368);
			this.txtSearchCustomer.Name = "txtSearchCustomer";
			this.txtSearchCustomer.Size = new System.Drawing.Size(168, 20);
			this.txtSearchCustomer.TabIndex = 4;
			this.txtSearchCustomer.Text = "";
			// 
			// cmdGetCustomer
			// 
			this.cmdGetCustomer.Location = new System.Drawing.Point(208, 368);
			this.cmdGetCustomer.Name = "cmdGetCustomer";
			this.cmdGetCustomer.Size = new System.Drawing.Size(96, 24);
			this.cmdGetCustomer.TabIndex = 7;
			this.cmdGetCustomer.Text = "Get Customer";
			this.cmdGetCustomer.Click += new System.EventHandler(this.cmdGetCustomer_Click);
			// 
			// groupBox1
			// 
			this.groupBox1.Location = new System.Drawing.Point(8, 8);
			this.groupBox1.Name = "groupBox1";
			this.groupBox1.Size = new System.Drawing.Size(352, 64);
			this.groupBox1.TabIndex = 6;
			this.groupBox1.TabStop = false;
			this.groupBox1.Text = " Server Time ";
			// 
			// oAuthorList
			// 
			this.oAuthorList.Location = new System.Drawing.Point(16, 112);
			this.oAuthorList.Name = "oAuthorList";
			this.oAuthorList.Size = new System.Drawing.Size(152, 173);
			this.oAuthorList.TabIndex = 3;
			this.oAuthorList.SelectedIndexChanged += new System.EventHandler(this.oAuthorList_SelectedIndexChanged);
			// 
			// txtPhone
			// 
			this.txtPhone.Location = new System.Drawing.Point(182, 264);
			this.txtPhone.Name = "txtPhone";
			this.txtPhone.Size = new System.Drawing.Size(168, 20);
			this.txtPhone.TabIndex = 4;
			this.txtPhone.Text = "";
			// 
			// cmdGetServerTime
			// 
			this.cmdGetServerTime.Location = new System.Drawing.Point(248, 32);
			this.cmdGetServerTime.Name = "cmdGetServerTime";
			this.cmdGetServerTime.Size = new System.Drawing.Size(104, 24);
			this.cmdGetServerTime.TabIndex = 2;
			this.cmdGetServerTime.Text = "Get Server Time";
			this.cmdGetServerTime.Click += new System.EventHandler(this.cmdGetServerTime_Click);
			// 
			// WebDemoClient
			// 
			this.AutoScaleBaseSize = new System.Drawing.Size(5, 13);
			this.ClientSize = new System.Drawing.Size(368, 549);
			this.Controls.AddRange(new System.Windows.Forms.Control[] {
																		  this.label7,
																		  this.label6,
																		  this.label5,
																		  this.label4,
																		  this.txtCustEmail,
																		  this.txtCustPhone,
																		  this.txtCustAddress,
																		  this.txtCustName,
																		  this.cmdGetCustomer,
																		  this.txtSearchCustomer,
																		  this.txtPhone,
																		  this.txtAddress,
																		  this.txtName,
																		  this.cmdGetAuthors,
																		  this.oAuthorList,
																		  this.cmdGetServerTime,
																		  this.label1,
																		  this.txtServerTime,
																		  this.groupBox1,
																		  this.groupBox2,
																		  this.label3,
																		  this.groupBox3});
			this.Name = "WebDemoClient";
			this.Text = "Web Service Client Demos";
			this.Load += new System.EventHandler(this.WebDemoClient_Load);
			this.groupBox2.ResumeLayout(false);
			this.ResumeLayout(false);

		}
		#endregion

		

		public WebDemoClient()
		{
			//
			// Required for Windows Form Designer support
			//
			InitializeComponent();

			//
			// TODO: Add any constructor code after InitializeComponent call
			//
		}



		/// <summary>
		///		Clean up any resources being used.
		/// </summary>
		protected override void Dispose( bool disposing )
		{
			if( disposing )
			{
				if(components != null)
				{
					components.Dispose();
				}
			}
			base.Dispose( disposing );
		}

		public void GetServerTime()
		{
			CodeClient.CodeWebService.CodeWebService oService = new CodeWebService();

			this.txtServerTime.Text = oService.GetServerTime().ToString();
		}
		/// <summary>
		/// Returns an authorlist. 
		/// </summary>
		public void GetAuthorList() 
		{
			CodeWebService oService = new CodeWebService();

			ds = oService.GetAuthorData("%");

			oAuthorList.Items.Clear();
			for (int x=0;x < ds.Tables["Authors"].Rows.Count; x++) 
			{
				oAuthorList.Items.Add(ds.Tables["Authors"].Rows[x]["au_lname"].ToString().Trim() +", " +
					                  ds.Tables["Authors"].Rows[x]["au_fname"].ToString());
			}
		}

		public void GetCustomer(string lcName)
		{
			CodeWebService oService = new CodeWebService();
			
			Customer oCust = new Customer();
						
			oCust = oService.GetCustomerByName(lcName);
	
			if (oCust == null) 
			{
				MessageBox.Show("Customer not found","WebService Demos");
				return;
			}

			txtCustName.Text = oCust.cFirstName.Trim() + " " + oCust.cLastName;
			txtCustAddress.Text = oCust.oAddress.cAddress;
			txtCustPhone.Text = oCust.oAddress.cPhone;
			txtCustEmail.Text = oCust.oAddress.cEmail;

			
		}
			


		private void cmdGetServerTime_Click(object sender, System.EventArgs e)
		{
			GetServerTime();
		}

		private void cmdGetAuthors_Click(object sender, System.EventArgs e)
		{
			GetAuthorList();
		}



		private void oAuthorList_SelectedIndexChanged(object sender, System.EventArgs e)
		{
			int lnIndex = oAuthorList.SelectedIndex;
			
			DataRow loRow = ds.Tables["Authors"].Rows[lnIndex];

			txtName.Text = loRow["au_lname"].ToString().Trim() + ", "  + loRow["au_fname"].ToString();
			txtAddress.Text = loRow["address"].ToString() + "\r\n" +
				loRow["city"].ToString() + " " + 
				loRow["state"] + ", " + loRow["zip"].ToString();
			txtPhone.Text = loRow["phone"].ToString();
			//txtPk.Text = loRow["au_id"].ToString();
		}

		private void cmdGetCustomer_Click(object sender, System.EventArgs e)
		{
			GetCustomer(txtSearchCustomer.Text);
		}

		private void WebDemoClient_Load(object sender, System.EventArgs e)
		{
		}

		private void button1_Click(object sender, System.EventArgs e)
		{
			
		}
	

	

	
	} // End of class

}  /// Namespace
