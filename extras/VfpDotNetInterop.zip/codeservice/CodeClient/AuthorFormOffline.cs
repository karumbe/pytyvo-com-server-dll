using System;
using System.IO;

using System.Drawing;
using System.Collections;
using System.ComponentModel;
using System.Windows.Forms;

using System.Data;

using CodeClient.TypeWebService;

namespace CodeClient
{

	/// <summary>
	/// Summary description for AuthorForm.
	/// </summary>
	public class AuthorFormOffline : System.Windows.Forms.Form
	{
		const bool USE_DATABINDING   = false;

		private DataSet oDS;
		private int nIndex;   // Author Index

		private System.Windows.Forms.ListBox oAuthorList;
		private System.Windows.Forms.Button button1;
		private System.Windows.Forms.Button cmdSave;
		private System.Windows.Forms.TextBox txtLastName;
		private System.Windows.Forms.TextBox txtFirstName;
		private System.Windows.Forms.Label label1;
		private System.Windows.Forms.Label label2;
		private System.Windows.Forms.TextBox txtAddress;
		private System.Windows.Forms.Label label3;
		private System.Windows.Forms.Label label5;
		private System.Windows.Forms.TextBox txtPhone;
		private System.Windows.Forms.CheckBox chkContract;
		private System.Windows.Forms.Button cmdUpdate;
		/// <summary>
		/// Required designer variable.
		/// </summary>
		private System.ComponentModel.Container components = null;

		public AuthorFormOffline()
		{
			//
			// Required for Windows Form Designer support
			//
			InitializeComponent();

			//
			// TODO: Add any constructor code after InitializeComponent call
			//
			oDS = new DataSet();
			
			GetAuthors();

		}

		/// <summary>
		/// Clean up any resources being used.
		/// </summary>
		protected override void Dispose( bool disposing )
		{
			if( disposing )
			{
				if(components != null)
				{
					components.Dispose();
				}
			}
			base.Dispose( disposing );
		}

		#region Windows Form Designer generated code
		/// <summary>
		/// Required method for Designer support - do not modify
		/// the contents of this method with the code editor.
		/// </summary>
		private void InitializeComponent()
		{
			this.txtFirstName = new System.Windows.Forms.TextBox();
			this.txtPhone = new System.Windows.Forms.TextBox();
			this.label5 = new System.Windows.Forms.Label();
			this.label1 = new System.Windows.Forms.Label();
			this.label2 = new System.Windows.Forms.Label();
			this.cmdSave = new System.Windows.Forms.Button();
			this.txtAddress = new System.Windows.Forms.TextBox();
			this.txtLastName = new System.Windows.Forms.TextBox();
			this.label3 = new System.Windows.Forms.Label();
			this.oAuthorList = new System.Windows.Forms.ListBox();
			this.button1 = new System.Windows.Forms.Button();
			this.chkContract = new System.Windows.Forms.CheckBox();
			this.cmdUpdate = new System.Windows.Forms.Button();
			this.SuspendLayout();
			// 
			// txtFirstName
			// 
			this.txtFirstName.Font = new System.Drawing.Font("Tahoma", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((System.Byte)(0)));
			this.txtFirstName.Location = new System.Drawing.Point(376, 8);
			this.txtFirstName.Name = "txtFirstName";
			this.txtFirstName.Size = new System.Drawing.Size(96, 21);
			this.txtFirstName.TabIndex = 6;
			this.txtFirstName.Text = "";
			// 
			// txtPhone
			// 
			this.txtPhone.Font = new System.Drawing.Font("Tahoma", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((System.Byte)(0)));
			this.txtPhone.Location = new System.Drawing.Point(232, 136);
			this.txtPhone.Name = "txtPhone";
			this.txtPhone.Size = new System.Drawing.Size(240, 21);
			this.txtPhone.TabIndex = 6;
			this.txtPhone.Text = "";
			// 
			// label5
			// 
			this.label5.BackColor = System.Drawing.Color.Transparent;
			this.label5.Font = new System.Drawing.Font("Tahoma", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((System.Byte)(0)));
			this.label5.Location = new System.Drawing.Point(184, 136);
			this.label5.Name = "label5";
			this.label5.Size = new System.Drawing.Size(48, 16);
			this.label5.TabIndex = 7;
			this.label5.Text = "Phone:";
			this.label5.TextAlign = System.Drawing.ContentAlignment.BottomRight;
			// 
			// label1
			// 
			this.label1.BackColor = System.Drawing.Color.Transparent;
			this.label1.Font = new System.Drawing.Font("Tahoma", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((System.Byte)(0)));
			this.label1.Location = new System.Drawing.Point(184, 8);
			this.label1.Name = "label1";
			this.label1.Size = new System.Drawing.Size(48, 16);
			this.label1.TabIndex = 7;
			this.label1.Text = "Last:";
			this.label1.TextAlign = System.Drawing.ContentAlignment.BottomRight;
			// 
			// label2
			// 
			this.label2.BackColor = System.Drawing.Color.Transparent;
			this.label2.Font = new System.Drawing.Font("Tahoma", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((System.Byte)(0)));
			this.label2.Location = new System.Drawing.Point(328, 8);
			this.label2.Name = "label2";
			this.label2.Size = new System.Drawing.Size(48, 16);
			this.label2.TabIndex = 7;
			this.label2.Text = "First:";
			this.label2.TextAlign = System.Drawing.ContentAlignment.BottomRight;
			// 
			// cmdSave
			// 
			this.cmdSave.Font = new System.Drawing.Font("Tahoma", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((System.Byte)(0)));
			this.cmdSave.Location = new System.Drawing.Point(397, 160);
			this.cmdSave.Name = "cmdSave";
			this.cmdSave.Size = new System.Drawing.Size(75, 24);
			this.cmdSave.TabIndex = 5;
			this.cmdSave.Text = "&Save";
			this.cmdSave.Click += new System.EventHandler(this.cmdSave_Click);
			// 
			// txtAddress
			// 
			this.txtAddress.Location = new System.Drawing.Point(232, 32);
			this.txtAddress.Multiline = true;
			this.txtAddress.Name = "txtAddress";
			this.txtAddress.Size = new System.Drawing.Size(240, 96);
			this.txtAddress.TabIndex = 8;
			this.txtAddress.Text = "";
			// 
			// txtLastName
			// 
			this.txtLastName.Font = new System.Drawing.Font("Tahoma", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((System.Byte)(0)));
			this.txtLastName.Location = new System.Drawing.Point(232, 8);
			this.txtLastName.Name = "txtLastName";
			this.txtLastName.Size = new System.Drawing.Size(96, 21);
			this.txtLastName.TabIndex = 6;
			this.txtLastName.Text = "";
			// 
			// label3
			// 
			this.label3.BackColor = System.Drawing.Color.Transparent;
			this.label3.Font = new System.Drawing.Font("Tahoma", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((System.Byte)(0)));
			this.label3.Location = new System.Drawing.Point(184, 32);
			this.label3.Name = "label3";
			this.label3.Size = new System.Drawing.Size(48, 16);
			this.label3.TabIndex = 7;
			this.label3.Text = "Address:";
			this.label3.TextAlign = System.Drawing.ContentAlignment.BottomRight;
			// 
			// oAuthorList
			// 
			this.oAuthorList.Font = new System.Drawing.Font("Tahoma", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((System.Byte)(0)));
			this.oAuthorList.Name = "oAuthorList";
			this.oAuthorList.Size = new System.Drawing.Size(168, 199);
			this.oAuthorList.TabIndex = 3;
			this.oAuthorList.SelectedIndexChanged += new System.EventHandler(this.oAuthorList_SelectedIndexChanged);
			// 
			// button1
			// 
			this.button1.Font = new System.Drawing.Font("Tahoma", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((System.Byte)(0)));
			this.button1.Location = new System.Drawing.Point(0, 200);
			this.button1.Name = "button1";
			this.button1.Size = new System.Drawing.Size(168, 24);
			this.button1.TabIndex = 4;
			this.button1.Text = "Refresh List";
			this.button1.Click += new System.EventHandler(this.button1_Click);
			// 
			// chkContract
			// 
			this.chkContract.Font = new System.Drawing.Font("Tahoma", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((System.Byte)(0)));
			this.chkContract.Location = new System.Drawing.Point(232, 160);
			this.chkContract.Name = "chkContract";
			this.chkContract.TabIndex = 9;
			this.chkContract.Text = "Has Contract";
			// 
			// cmdUpdate
			// 
			this.cmdUpdate.Font = new System.Drawing.Font("Tahoma", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((System.Byte)(0)));
			this.cmdUpdate.Location = new System.Drawing.Point(368, 192);
			this.cmdUpdate.Name = "cmdUpdate";
			this.cmdUpdate.Size = new System.Drawing.Size(104, 24);
			this.cmdUpdate.TabIndex = 10;
			this.cmdUpdate.Text = "Update Server";
			this.cmdUpdate.Click += new System.EventHandler(this.cmdUpdate_Click);
			// 
			// AuthorForm
			// 
			this.AutoScaleBaseSize = new System.Drawing.Size(5, 13);
			this.ClientSize = new System.Drawing.Size(480, 229);
			this.Controls.AddRange(new System.Windows.Forms.Control[] {
																		  this.cmdUpdate,
																		  this.chkContract,
																		  this.txtPhone,
																		  this.label5,
																		  this.label3,
																		  this.txtAddress,
																		  this.label2,
																		  this.label1,
																		  this.txtFirstName,
																		  this.txtLastName,
																		  this.cmdSave,
																		  this.button1,
																		  this.oAuthorList});
			this.Name = "AuthorForm";
			this.Text = "Authors";
			this.Load += new System.EventHandler(this.AuthorForm_Load);
			this.ResumeLayout(false);

		}
		#endregion

		private void AuthorForm_Load(object sender, System.EventArgs e)
		{
		}
	
		private void GetAuthors()
		{
			GetAuthors(true);
		}

		private void GetAuthors(bool llRefresh)
		{
			if (llRefresh) 
			{
				ComplexTypes oService = new ComplexTypes();

				try 
				{
					oDS = oService.GetAuthors("%");
				}
				catch(Exception e) 
				{
					MessageBox.Show(e.Message);
					return;
				}
			}

			/// Manually populate the list
			oAuthorList.Items.Clear();

			DataTable oTable = oDS.Tables["Authors"];
			for (int x=0;x < oTable.Rows.Count; x++) 
			{
				oAuthorList.Items.Add(oTable.Rows[x]["au_lname"].ToString().Trim() +", " +
					oTable.Rows[x]["au_fname"].ToString());
			}
		}

		private void button1_Click(object sender, System.EventArgs e)
		{
			this.GetAuthors();
		}

		private void oAuthorList_SelectedIndexChanged(object sender, System.EventArgs e)
		{
		
			BindData();
		}

		private void cmdSave_Click(object sender, System.EventArgs e)
		{
			SaveAuthor();
		}

				
		public void SaveAuthor() 
		{
			/// Update local DataSet only
			DataRow loRow = oDS.Tables["Authors"].Rows[nIndex];

			/// Manually pick up the data
			loRow["au_lname"] = txtLastName.Text;
			loRow["au_fname"] = txtFirstName.Text;
			loRow["address"] = txtAddress.Text;
			loRow["phone"] = txtPhone.Text;
			if (chkContract.Checked)
				loRow["Contract"] = true;
			else
				loRow["Contract"] = false;

			
			/// Refresh the list but don't refetch the data
			GetAuthors(false);  

			/// reselect item
			oAuthorList.SelectedIndex = nIndex;  
			
		}

		public void UpdateAuthors()
		{

			/// This should show all the changed records in the record set
			// MessageBox.Show(ShowDS(oDS.GetChanges()));

			/// Send it back up to the server!
			ComplexTypes oService = new ComplexTypes();

			// oDS.AcceptChanges();  // Don't call this - do it on the server!

			bool llResult = false;

			/// Call the Web Service with the PK
			try 
			{
				llResult = oService.SaveAuthors( oDS );
			}
			catch(Exception ex) 
			{
				MessageBox.Show(ex.Message);
				return;
			}

			if (llResult)
				MessageBox.Show("Authors Saved");
			else
				MessageBox.Show("Authors were not saved");

			GetAuthors();

		}

		public void BindData()
		{
			/// Get the index of the item selected
			nIndex = oAuthorList.SelectedIndex;
			
			/// grab the data row
			DataRow loRow = oDS.Tables["Authors"].Rows[nIndex];

			/// Now manually bind the data to the data row - so updates
			/// go straight back to the DataTable in the DataSet
			txtLastName.Text = loRow["au_lname"].ToString();
			txtFirstName.Text = loRow["au_fname"].ToString();
			txtAddress.Text = loRow["address"].ToString();
			txtPhone.Text = loRow["phone"].ToString();
			chkContract.Checked = ((bool) loRow["contract"]) ? true : false;
		}

		
		public string ShowDS(DataSet loDS)
		{
			System.IO.StringWriter loStream = new System.IO.StringWriter();
			loDS.WriteXml(loStream);

			return loStream.ToString();
		}

		private void cmdUpdate_Click(object sender, System.EventArgs e)
		{
			this.UpdateAuthors();
		}


	}
		
}
