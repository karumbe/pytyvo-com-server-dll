vti_encoding:SR|utf8-nl
vti_timelastmodified:TR|07 Dec 2001 10:34:40 -0000
vti_extenderversion:SR|5.0.2.3311
vti_lineageid:SR|{9E6C6117-877F-496C-988D-E888141C7BB0}
vti_cacheddtm:TX|07 Dec 2001 10:34:40 -0000
vti_filesize:IR|12132
vti_backlinkinfo:VX|
