vti_encoding:SR|utf8-nl
vti_timelastmodified:TR|07 Dec 2001 10:35:24 -0000
vti_extenderversion:SR|5.0.2.3311
vti_lineageid:SR|{83612937-6A88-409F-9692-32EB6783E52F}
vti_cacheddtm:TX|07 Dec 2001 10:35:24 -0000
vti_filesize:IR|6889
vti_backlinkinfo:VX|
