
/// debug flag used to demonstrate databinding and manual
/// data display -  comment to use manual databinding
#define USE_DATABINDING

using System;
using System.IO;

using System.Drawing;
using System.Collections;
using System.ComponentModel;
using System.Windows.Forms;

using System.Data;

using System.Net;
using CodeClient.TypeWebService;



namespace CodeClient
{

	/// <summary>
	/// Summary description for AuthorForm.
	/// </summary>
	public class AuthorForm : System.Windows.Forms.Form
	{
		///const bool USE_DATABINDING   = true;

		private DataSet oDS;
		private DataSet oAuthorDS;

		private System.Windows.Forms.ListBox oAuthorList;
		private System.Windows.Forms.Button button1;
		private System.Windows.Forms.Button cmdSave;
		private System.Windows.Forms.TextBox txtLastName;
		private System.Windows.Forms.TextBox txtFirstName;
		private System.Windows.Forms.Label label1;
		private System.Windows.Forms.Label label2;
		private System.Windows.Forms.TextBox txtAddress;
		private System.Windows.Forms.Label label3;
		private System.Windows.Forms.Label label5;
		private System.Windows.Forms.TextBox txtPhone;
		private System.Windows.Forms.CheckBox chkContract;
		/// <summary>
		/// Required designer variable.
		/// </summary>
		private System.ComponentModel.Container components = null;

		public AuthorForm()
		{
			//
			// Required for Windows Form Designer support
			//
			InitializeComponent();

			//
			// TODO: Add any constructor code after InitializeComponent call
			//
			oDS = new DataSet();
			oAuthorDS = new DataSet();

			GetAuthorList();
		}

		/// <summary>
		/// Clean up any resources being used.
		/// </summary>
		protected override void Dispose( bool disposing )
		{
			if( disposing )
			{
				if(components != null)
				{
					components.Dispose();
				}
			}
			base.Dispose( disposing );
		}

		#region Windows Form Designer generated code
		/// <summary>
		/// Required method for Designer support - do not modify
		/// the contents of this method with the code editor.
		/// </summary>
		private void InitializeComponent()
		{
			this.txtFirstName = new System.Windows.Forms.TextBox();
			this.txtPhone = new System.Windows.Forms.TextBox();
			this.label5 = new System.Windows.Forms.Label();
			this.label1 = new System.Windows.Forms.Label();
			this.label2 = new System.Windows.Forms.Label();
			this.cmdSave = new System.Windows.Forms.Button();
			this.txtAddress = new System.Windows.Forms.TextBox();
			this.txtLastName = new System.Windows.Forms.TextBox();
			this.chkContract = new System.Windows.Forms.CheckBox();
			this.label3 = new System.Windows.Forms.Label();
			this.oAuthorList = new System.Windows.Forms.ListBox();
			this.button1 = new System.Windows.Forms.Button();
			this.SuspendLayout();
			// 
			// txtFirstName
			// 
			this.txtFirstName.Font = new System.Drawing.Font("Tahoma", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((System.Byte)(0)));
			this.txtFirstName.Location = new System.Drawing.Point(370, 24);
			this.txtFirstName.Name = "txtFirstName";
			this.txtFirstName.Size = new System.Drawing.Size(96, 21);
			this.txtFirstName.TabIndex = 6;
			this.txtFirstName.Text = "";
			// 
			// txtPhone
			// 
			this.txtPhone.Font = new System.Drawing.Font("Tahoma", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((System.Byte)(0)));
			this.txtPhone.Location = new System.Drawing.Point(226, 147);
			this.txtPhone.Name = "txtPhone";
			this.txtPhone.Size = new System.Drawing.Size(240, 21);
			this.txtPhone.TabIndex = 6;
			this.txtPhone.Text = "";
			// 
			// label5
			// 
			this.label5.BackColor = System.Drawing.Color.Transparent;
			this.label5.Font = new System.Drawing.Font("Tahoma", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((System.Byte)(0)));
			this.label5.Location = new System.Drawing.Point(175, 150);
			this.label5.Name = "label5";
			this.label5.Size = new System.Drawing.Size(48, 16);
			this.label5.TabIndex = 7;
			this.label5.Text = "Phone:";
			this.label5.TextAlign = System.Drawing.ContentAlignment.BottomRight;
			// 
			// label1
			// 
			this.label1.BackColor = System.Drawing.Color.Transparent;
			this.label1.Font = new System.Drawing.Font("Tahoma", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((System.Byte)(0)));
			this.label1.Location = new System.Drawing.Point(175, 27);
			this.label1.Name = "label1";
			this.label1.Size = new System.Drawing.Size(48, 16);
			this.label1.TabIndex = 7;
			this.label1.Text = "Last:";
			this.label1.TextAlign = System.Drawing.ContentAlignment.BottomRight;
			// 
			// label2
			// 
			this.label2.BackColor = System.Drawing.Color.Transparent;
			this.label2.Font = new System.Drawing.Font("Tahoma", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((System.Byte)(0)));
			this.label2.Location = new System.Drawing.Point(322, 27);
			this.label2.Name = "label2";
			this.label2.Size = new System.Drawing.Size(48, 16);
			this.label2.TabIndex = 7;
			this.label2.Text = "First:";
			this.label2.TextAlign = System.Drawing.ContentAlignment.BottomRight;
			// 
			// cmdSave
			// 
			this.cmdSave.Font = new System.Drawing.Font("Tahoma", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((System.Byte)(0)));
			this.cmdSave.Location = new System.Drawing.Point(392, 172);
			this.cmdSave.Name = "cmdSave";
			this.cmdSave.Size = new System.Drawing.Size(75, 25);
			this.cmdSave.TabIndex = 5;
			this.cmdSave.Text = "&Save";
			this.cmdSave.Click += new System.EventHandler(this.cmdSave_Click);
			// 
			// txtAddress
			// 
			this.txtAddress.Location = new System.Drawing.Point(226, 48);
			this.txtAddress.Multiline = true;
			this.txtAddress.Name = "txtAddress";
			this.txtAddress.Size = new System.Drawing.Size(240, 96);
			this.txtAddress.TabIndex = 8;
			this.txtAddress.Text = "";
			// 
			// txtLastName
			// 
			this.txtLastName.Font = new System.Drawing.Font("Tahoma", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((System.Byte)(0)));
			this.txtLastName.Location = new System.Drawing.Point(226, 24);
			this.txtLastName.Name = "txtLastName";
			this.txtLastName.Size = new System.Drawing.Size(96, 21);
			this.txtLastName.TabIndex = 6;
			this.txtLastName.Text = "";
			// 
			// chkContract
			// 
			this.chkContract.Font = new System.Drawing.Font("Tahoma", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((System.Byte)(0)));
			this.chkContract.Location = new System.Drawing.Point(227, 169);
			this.chkContract.Name = "chkContract";
			this.chkContract.TabIndex = 9;
			this.chkContract.Text = "Has Contract";
			this.chkContract.CheckedChanged += new System.EventHandler(this.chkContract_CheckedChanged);
			// 
			// label3
			// 
			this.label3.BackColor = System.Drawing.Color.Transparent;
			this.label3.Font = new System.Drawing.Font("Tahoma", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((System.Byte)(0)));
			this.label3.Location = new System.Drawing.Point(175, 50);
			this.label3.Name = "label3";
			this.label3.Size = new System.Drawing.Size(48, 16);
			this.label3.TabIndex = 7;
			this.label3.Text = "Address:";
			this.label3.TextAlign = System.Drawing.ContentAlignment.BottomRight;
			// 
			// oAuthorList
			// 
			this.oAuthorList.Font = new System.Drawing.Font("Tahoma", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((System.Byte)(0)));
			this.oAuthorList.Name = "oAuthorList";
			this.oAuthorList.Size = new System.Drawing.Size(168, 199);
			this.oAuthorList.TabIndex = 3;
			this.oAuthorList.SelectedIndexChanged += new System.EventHandler(this.oAuthorList_SelectedIndexChanged);
			// 
			// button1
			// 
			this.button1.Font = new System.Drawing.Font("Tahoma", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((System.Byte)(0)));
			this.button1.Location = new System.Drawing.Point(0, 200);
			this.button1.Name = "button1";
			this.button1.Size = new System.Drawing.Size(168, 24);
			this.button1.TabIndex = 4;
			this.button1.Text = "Refresh List";
			this.button1.Click += new System.EventHandler(this.button1_Click);
			// 
			// AuthorForm
			// 
			this.AutoScaleBaseSize = new System.Drawing.Size(5, 13);
			this.ClientSize = new System.Drawing.Size(474, 224);
			this.Controls.AddRange(new System.Windows.Forms.Control[] {
																		  this.chkContract,
																		  this.txtPhone,
																		  this.label5,
																		  this.label3,
																		  this.txtAddress,
																		  this.label2,
																		  this.label1,
																		  this.txtFirstName,
																		  this.txtLastName,
																		  this.cmdSave,
																		  this.button1,
																		  this.oAuthorList});
			this.Name = "AuthorForm";
			this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
			this.Text = "Authors";
			this.Load += new System.EventHandler(this.AuthorForm_Load);
			this.ResumeLayout(false);

		}
		#endregion

		private void AuthorForm_Load(object sender, System.EventArgs e)
		{
		}

		private void GetAuthorList()
		{
			ComplexTypes oService = new ComplexTypes();
			

			/// Allow Authentication on the server against local user account
			/// oService.Credentials = CredentialCache.DefaultCredentials;
			//oService.Credentials = new NetworkCredential("rstrahl", "password");

			try 
			{
				oDS = oService.GetAuthorList("%");
			}
			catch(Exception e) 
			{
				MessageBox.Show(e.Message);
				return;
			}
			/// MessageBox.Show( ShowDS(oDS) );

			/// Direct data binding code - can't show composite data if SQL doesn't include it
			oAuthorList.DataSource = oDS.Tables["Authors"];
			oAuthorList.DisplayMember = "name";
			oAuthorList.ValueMember = "pk";
		

			/// Manually populate the list
			/// 
			/*
			oAuthorList.Items.Clear();

			DataTable oTable = oDS.Tables["Authors"];
			for (int x=0;x < oTable.Rows.Count; x++) 
			{
				oAuthorList.Items.Add(oTable.Rows[x]["au_lname"].ToString().Trim() +", " +
					oTable.Rows[x]["au_fname"].ToString());
			}
			*/
		}

		private void button1_Click(object sender, System.EventArgs e)
		{
			this.GetAuthorList();
		}

		private void oAuthorList_SelectedIndexChanged(object sender, System.EventArgs e)
		{
		
			BindData();
		}

		private void cmdSave_Click(object sender, System.EventArgs e)
		{
			SaveAuthor();

		}

				
		public void SaveAuthor() 
		{
			/// Simulate making some changes to the current record
			DataRow loRow = oAuthorDS.Tables["Author"].Rows[0];


#if USE_DATABINDING
			this.BindingContext[oAuthorDS,"Author"].EndCurrentEdit();
#else
			/// Manually pick up the data
			loRow["au_lname"] = txtLastName.Text;
			loRow["au_fname"] = txtFirstName.Text;
			loRow["address"] = txtAddress.Text;
			loRow["phone"] = txtPhone.Text;
			if (chkContract.Checked)
				loRow["Contract"] = 1;
			else
				loRow["Contract"] = 0;
#endif

			//MessageBox.Show(ShowDS(oAuthorDS.GetChanges()));

			/// Send it back up to the server!
			ComplexTypes oService = new ComplexTypes();

			/// oAuthorDS.AcceptChanges();

			bool llResult = false;

			/// Call the Web Service with the PK
			try 
			{
				llResult = oService.SaveAuthor( oAuthorDS );
			}
			catch(Exception ex) 
			{
				MessageBox.Show(ex.Message);
				return;
			}

			if (llResult)
			MessageBox.Show("Author Saved");
			else
			MessageBox.Show("Author was not saved");
		}


		public void BindData()
		{
			DataRow loRow = oDS.Tables["Authors"].Rows[oAuthorList.SelectedIndex];

			ComplexTypes oService = new ComplexTypes();

			/// Call the Web Service with the PK
			try 
			{
				/// Must cast so compiler won't complain
				oAuthorDS = oService.GetAuthor( (int)loRow["pk"] );
				// oAuthorDS = oService.GetAuthor( (int)oAuthorList.SelectedValue );
			}
			catch(Exception ex) 
			{
				MessageBox.Show(ex.Message);
				return;
			}

			if (oAuthorDS == null) {
				MessageBox.Show("Couldn't load customer");
				return;
			}


#if USE_DATABINDING
			/// This code uses control data binding
			/// Unfortunately this didn't work correctly - the only
			/// way I could make it work was by rebinding the control
			/// each time the dataset is updated.
			if (false) // txtLastName.DataBindings.Count > 0) 
			{
				/// Try to refresh the binding --- doesn't work
				this.BindingContext[oAuthorDS,"Author"].Position = 0;
			}
			else 
			{
				/// Rebind each time data is updated
				/// More work, but still useful as it writes data back to
				/// the current dataset without any further code
				txtLastName.DataBindings.Clear();
				txtLastName.DataBindings.Add(new Binding("Text",oAuthorDS.Tables["Author"],"au_lname"));

				txtFirstName.DataBindings.Clear();
				txtFirstName.DataBindings.Add(new Binding("Text",oAuthorDS.Tables["Author"],"au_fname"));

				txtAddress.DataBindings.Clear();
				txtAddress.DataBindings.Add(new Binding("Text",oAuthorDS.Tables["Author"],"address"));

				txtPhone.DataBindings.Clear();
				txtPhone.DataBindings.Add(new Binding("Text",oAuthorDS.Tables["Author"],"phone"));

				chkContract.DataBindings.Clear();
				chkContract.DataBindings.Add(new Binding("Checked",oAuthorDS.Tables["Author"],"contract"));
			}
#else
			/// Manually set and restore the data to the controls
			loRow = oAuthorDS.Tables["Author"].Rows[0];
			txtLastName.Text = loRow["au_lname"].ToString();
			txtFirstName.Text = loRow["au_fname"].ToString();
			txtAddress.Text = loRow["address"].ToString();
			txtPhone.Text = loRow["phone"].ToString();
			chkContract.Checked = ((bool) loRow["contract"]) ? true : false;
#endif
		}

		
		public string ShowDS(DataSet loDS)
		{
			System.IO.StringWriter loStream = new System.IO.StringWriter();
			loDS.WriteXml(loStream);

			return loStream.ToString();
		}

		private void chkContract_CheckedChanged(object sender, System.EventArgs e)
		{

		}


	}
		
}
