using System;
using System;
using System.Collections;
using System.ComponentModel;
using System.Windows.Forms;


namespace CodeClient
{
	/// <summary>
	/// Summary description for Startup.
	/// </summary>
	public class Startup
	{
		public Startup()
		{
			//
			// TODO: Add constructor logic here
			//
		}

		/// <summary>
		///  Start Program MAIN to start the application running
		/// </summary>
		/// <param name="args"></param>
		public static void Main(string[] args) 
		{
			Application.Run(new WebDemoClient.WebDemoClient());
		}

	}
}
