using System;
using System.Drawing;
using System.Collections;
using System.ComponentModel;
using System.Windows.Forms;
using WestWind;

using System.Data;
using System.Data.SqlClient;

namespace CodeClient
{
	/// <summary>
	/// Summary description for wwBusinessTest.
	/// </summary>
	public class wwBusinessTest : System.Windows.Forms.Form
	{

		wwBusiness oBus;
		private System.Windows.Forms.Button cmdQuery;
		private System.Windows.Forms.Button cmdLoad;
		/// <summary>
		/// Required designer variable.
		/// </summary>
		private System.ComponentModel.Container components = null;

		public wwBusinessTest()
		{
			//
			// Required for Windows Form Designer support
			//
			InitializeComponent();

			oBus = new wwBusiness();
			oBus.cConnectString =  "server=(local);uid=sa;pwd=;database=WestWindWebStore";
			oBus.cFilename = "wws_customers";

			//
			// TODO: Add any constructor code after InitializeComponent call
			//
		}

		/// <summary>
		/// Clean up any resources being used.
		/// </summary>
		protected override void Dispose( bool disposing )
		{
			if( disposing )
			{
				if(components != null)
				{
					components.Dispose();
				}
			}
			base.Dispose( disposing );
		}

		#region Windows Form Designer generated code
		/// <summary>
		/// Required method for Designer support - do not modify
		/// the contents of this method with the code editor.
		/// </summary>
		private void InitializeComponent()
		{
			this.cmdQuery = new System.Windows.Forms.Button();
			this.cmdLoad = new System.Windows.Forms.Button();
			this.SuspendLayout();
			// 
			// cmdQuery
			// 
			this.cmdQuery.Location = new System.Drawing.Point(80, 200);
			this.cmdQuery.Name = "cmdQuery";
			this.cmdQuery.Size = new System.Drawing.Size(104, 32);
			this.cmdQuery.TabIndex = 0;
			this.cmdQuery.Text = "Query";
			this.cmdQuery.Click += new System.EventHandler(this.cmdQuery_Click);
			// 
			// cmdLoad
			// 
			this.cmdLoad.Location = new System.Drawing.Point(80, 144);
			this.cmdLoad.Name = "cmdLoad";
			this.cmdLoad.Size = new System.Drawing.Size(104, 32);
			this.cmdLoad.TabIndex = 1;
			this.cmdLoad.Text = "Load";
			this.cmdLoad.Click += new System.EventHandler(this.cmdLoad_Click);
			// 
			// wwBusinessTest
			// 
			this.AutoScaleBaseSize = new System.Drawing.Size(5, 13);
			this.ClientSize = new System.Drawing.Size(292, 273);
			this.Controls.AddRange(new System.Windows.Forms.Control[] {
																		  this.cmdLoad,
																		  this.cmdQuery});
			this.Name = "wwBusinessTest";
			this.Text = "wwBusinessTest";
			this.Load += new System.EventHandler(this.wwBusinessTest_Load);
			this.ResumeLayout(false);

		}
		#endregion

		private void cmdQuery_Click(object sender, System.EventArgs e)
		{

			int lnResult = oBus.Execute("select * from wws_customers","Customers");

			System.Data.DataTable loCursor;
			loCursor = oBus.oTable;
		
			MessageBox.Show(loCursor.Rows[0]["Company"].ToString());

			lnResult = oBus.Execute("select * from wws_invoice","Invoices");

			System.Data.DataTable loCursor2 = oBus.oTable;
		
			MessageBox.Show(loCursor.Rows[0]["Company"].ToString());
			MessageBox.Show(loCursor2.Rows[0]["invdate"].ToString());

		}

		private void cmdLoad_Click(object sender, System.EventArgs e)
		{
			if ( !oBus.Load(1) )
			{
				MessageBox.Show("Couldn't load customer.");
			}

			MessageBox.Show(oBus.oData["Company"].ToString());

			oBus.oData["Company"] = "West Wind Technologies";
		
			System.IO.StringWriter loStream = new System.IO.StringWriter();
			oBus.oDS.GetChanges().WriteXml(loStream);

			MessageBox.Show(loStream.ToString() );

			if (!oBus.Save())
				MessageBox.Show(oBus.cErrormsg);

		}

		private void wwBusinessTest_Load(object sender, System.EventArgs e)
		{

		}
	}
}
