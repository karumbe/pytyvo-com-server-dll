using System;
using System.IO;


using System.Windows.Forms;


using System.Data;
using System.Data.SqlTypes;
using System.Data.Common;
using System.Data.SqlClient;

namespace WestWind
{
	/// <summary>
	/// Summary description for wwBusiness.
	/// </summary>
	public class wwBusiness
	{

		/// <summary>
		/// Data member that gets set after a Load operation.
		/// Returns a DataRow object that can be accessed via loBus.oData["fieldname"]
		/// </summary>
		public System.Data.DataRow	oData = null;

		/// <summary>
		/// SQL Server SQLClient Connection string
		/// Example: server=(local);uid=sa;pwd=;database=WestWindWebStore
		/// </summary>
		public string				cConnectString = "";
		
		/// <summary>
		/// Base file name for the business object
		/// </summary>
		public string				cFilename = "";

		/// <summary>
		/// Reference to a Dataset object contains the results of the current query
		/// or row. 
		/// </summary>
		public DataSet				oDS = null;

		/// <summary>
		/// Reference to a DataTable object that contains the result from the most
		/// recent Query.
		/// </summary>
		public DataTable			oTable = null;				

		/// <summary>
		/// Reference to the SQL connection used to access data with. This property
		/// can be assigned explicitly to avoid reconnecting after each object creation. 
		/// </summary>
		public SqlConnection		oConn = null;

		/// <summary>
		///  Error flag. Can be set with SetError().
		/// </summary>
		public bool					lError = false;

		/// <summary>
		/// Error message.
		/// </summary>
		public string				cErrormsg = "";

		// public oError			

		/// <summary>
		/// Internal flag used to determine whether the cleanup code in the Release()
		/// method has been called already. 
		/// </summary>
		protected bool				lReleaseCalled = false;

		public bool					lAutoCloseConnection = false;

		public wwBusiness()
		{
			//
			// TODO: Add constructor logic here
			//
		}

		~wwBusiness()
		{
			//
			// TODO: Add constructor logic here
			//
			if (this.lReleaseCalled)
				this.Release();
		}
		
		/// <summary>
		/// Loads a DataRow object into the oData member based on the PK passed
		/// </summary>
		/// <param name="lnPk"></param>
		/// <returns></returns>
		public bool Load(int lnPk)
		{

			this.SetError();

			if (!this.Open())
				return false;

			int lnResult = this.Execute("select * from " + this.cFilename + " where pk=" + lnPk.ToString(),this.cFilename);

			if (this.lError)
			   return false;
				
			if (lnResult != 1)
				return false;

			this.oData = this.oTable.Rows[0];

			return true;
		}

		/// <summary>
		/// Saves the current oData member to the data source.
		/// </summary>
		/// <returns>bool</returns>
		public bool Save()
		{
			this.SetError();

			if (!this.Open())	
				return true;

			SqlDataAdapter oDSCommand = new SqlDataAdapter("select * from " + this.cFilename,this.oConn);

			/// This builds the Update/InsertCommands for the data adapter
			SqlCommandBuilder oCmdBuilder = new SqlCommandBuilder(oDSCommand);

			try 
			{
				oDSCommand.Update(oDS,this.cFilename);
			}
			catch(Exception e)
			{
				this.SetError(e.Message);
				return false;
			}

			return true;
		}


		/// <summary>
		/// Returns a query from the database
		/// </summary>
		/// <param name="lcSQL"></param>
		/// <returns></returns>
		public int Query(string lcSQL)
		{	
				return 0;
		}

		/// <summary>
		/// Sets up the connection for a query
		/// </summary>
		/// <returns></returns>
		public bool Open()
		{
			/// create if it doesn't exist already
			if (this.oConn == null) 
			{
				try 
				{
					this.oConn = new SqlConnection(this.cConnectString);
				}
				catch(Exception e)
				{
					this.SetError( e.Message );
					return false;
				}
			}

			/// check if connection is open - if not open it
			if (this.oConn.State != ConnectionState.Open) 
			{
				try 
				{
					oConn.Open();
				}
				catch(Exception e)
				{
					this.SetError( e.Message );
					return false;
				}
			}

			/// make sure our dataset object exists
			if (oDS == null) 
				oDS = new DataSet();

			return true;
		}

		public bool Close() 
		{
			if (oConn.State == ConnectionState.Open)
				try 
				{
					oConn.Close();
				}
				catch(Exception e)
				{
					this.SetError( e.Message );
					return false;
				}

			return true;
		}

		/// <summary>
		///  Executes a Select statement that returns a cursor.
		/// </summary>
		/// <param name="lcSQL"></param>
		/// <param name="lcCursor"></param>
		/// <returns></returns>
		public int Execute(string lcSQL, string lcCursor)
		{
			if (!this.Open()) 
				return 0;

			SqlDataAdapter oDSCommand = new SqlDataAdapter();
			oDSCommand.SelectCommand = 
				new SqlCommand(lcSQL,oConn);


			/// remove the table if it exists - fail and ignore
			try 
			{
				oDS.Tables.Remove(lcCursor);
			}
			catch(Exception e) { }  // Ignore the error
	
			try 
			{
				oDSCommand.Fill(oDS,lcCursor);
			}
			catch(Exception e)
			{
				this.SetError(e.Message);
				return 0;
			}

			this.oTable = oDS.Tables[lcCursor];

			return oDS.Tables[lcCursor].Rows.Count;
		}



		public void Release()
		{
			this.lReleaseCalled = true;
			
			if (this.lAutoCloseConnection)
				this.Close();
		}

		public void SetError(string lcErrormsg)
		{
			if (lcErrormsg.Length == 0) 
			{
				cErrormsg = "";
				lError = false;
				return;
			}

			cErrormsg = lcErrormsg;
			lError = true;
		}

		public void SetError()
		{
			SetError("");
		}

	}
}
